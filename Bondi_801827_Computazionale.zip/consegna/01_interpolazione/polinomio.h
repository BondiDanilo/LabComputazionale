#include <iostream>
#include <cmath>
#include <string>

#ifndef POLINOMIO
#define POLINOMIO


class Polinomio
{
 private:
  int _degree;
  double * _coefficients;
  double * _nodes;
  double _x_min, _x_max;
  bool _init_nodes;
public:
  Polinomio();
  Polinomio(int);
  Polinomio(int,double,double);
  ~Polinomio();
  double eval(double);
  void interp_newton(double (*func)(double)); // Function as argument
  void set_equi_nodes();
  void set_cheby_nodes();
  double get_node(int);
  double get_coeff(int);
  void print_coeff();
  void print();
};

//////////////////////////////////////////////////////////////////////
//                      Constructors                                //
//////////////////////////////////////////////////////////////////////

Polinomio::Polinomio(int degree, double x_min, double x_max)
{
  _degree = degree;
  _x_min = x_min;
  _x_max = x_max;
  _coefficients = new double[_degree+1];
  _nodes = new double[_degree+1];
  _init_nodes = 0;
  // Initialize Coefficients to 0
  for( int n=0 ; n<_degree+1; n++)
    _coefficients[n] = 0.;
}

Polinomio::Polinomio(int degree)
{
  _degree = degree;
  _x_min = -1.0;
  _x_max = 1.0;
  _coefficients = new double[_degree+1];
  _nodes = new double[_degree+1];
  _init_nodes = 0;
  // Initialize Coefficients to 0
  for( int n=0 ; n<_degree+1; n++)
    _coefficients[n] = 0.;
}

Polinomio::Polinomio()
{
  _degree = 1;
  _x_min = -1.0;
  _x_max = 1.0;
  _coefficients = new double[_degree+1];
  _nodes = new double[_degree+1];
  _init_nodes = 0;
    // Initialize Coefficients to 0
  for( int n=0 ; n<_degree+1; n++)
    _coefficients[n] = 0.;
}

Polinomio::~Polinomio()
{
  delete _coefficients;
  delete _nodes;
}
//////////////////////////////////////////////////////////////////////
//                     Interpolazione                               //
//////////////////////////////////////////////////////////////////////

void Polinomio::interp_newton(double (*func)(double))
{
  int n_nodes = _degree;
  double den, y[n_nodes];
  double P,PP;

  if(  _init_nodes == 0 )
    this->set_equi_nodes();
  // Primo Coefficiente
  _coefficients[0] = func(_nodes[0]);
  
  den = 1.;
   
  // Metodo di Newton per i coefficienti
  for(int i=1 ; i<n_nodes+1 ;i++)
  {
    den = 1.;
    // Calcolo polinomio di grado i-1
    PP = _coefficients[0];
    P = _coefficients[0];
    if (_degree > 0)
    {
      for (int k = 1; k<_degree+1 ; k++)
      {
	PP = _coefficients[k];
	for (int j=0; j<k;j++)
	  PP = PP * ( _nodes[i] - _nodes[j]);  

	P = P + PP;  					
      }
      
      // Calcola il denominatore
      for (int k=0;k<i;k++)
	den *= _nodes[i] - _nodes[k];
      // Calcolo del coefficiente
      _coefficients[i] = ( func(_nodes[i]) - P ) / den; 
    }
  }

  return;
}

//////////////////////////////////////////////////////////////////////
//                           Nodi                                   //
//////////////////////////////////////////////////////////////////////
void Polinomio::set_equi_nodes()
{
  _init_nodes = 1; 
   for (int i=0;i<_degree;i++)
     _nodes[i] = _x_min + (_x_max-_x_min) * (double) i / (_degree-1); 
  return;
}

void Polinomio::set_cheby_nodes()
{
  _init_nodes = 1;
  // Chebycev nodes in interval [a,b]
  for (int i=0 ; i<_degree ; i++)
  {
    _nodes[_degree-1-i]
      = 0.5*(_x_max - _x_min) * cos( M_PI * (i+0.5) / _degree ) + 0.5*(_x_min+_x_max);
  }
  return;
}

//////////////////////////////////////////////////////////////////////
//                       Funzioni GET                               //
//////////////////////////////////////////////////////////////////////

double Polinomio::get_node(int n)
{
  return _nodes[n];
}
double Polinomio::get_coeff(int n)
{
  return _coefficients[n];
}

double Polinomio::eval(double x)
{
  double y = _coefficients[0];
  double PP = 0.;
  for (int n = 1 ; n < _degree+1 ; n++)
  {
    PP = 1.;
    for (int k = 0 ; k < n ;k++)
      PP *= x-_nodes[k];
    y += _coefficients[n]*PP;
  }
  return y;
}

void Polinomio::print_coeff()
{
  for (int n=0; n<_degree+1; n++)
  {
    std::cout <<_coefficients[n] <<"\t";
  }
  std::cout <<std::endl;
  return;
}

void Polinomio::print()
{
  std::string str = "P(x) = ";

  str += std::to_string(_coefficients[0]);
  str +=" +";
  for (int n = 1 ; n < _degree+1 ; n++)
  {
    str += " ";
    str += std::to_string(_coefficients[n]);
    str +="*";
    for (int k = 0 ; k < n ;k++)
    {
      str += "(x";
      str += "-";
      str += std::to_string(_nodes[k]);
      str += ")";
    }
    str += " ";
    if(n<_degree)
      str += "+ ";
  }
  //////////
   
  std::cout <<std::endl <<str <<std::endl;
  return;
}

#endif
