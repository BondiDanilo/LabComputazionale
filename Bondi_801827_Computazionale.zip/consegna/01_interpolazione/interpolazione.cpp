#include <iostream>
#include <fstream>

#include <cmath>
#include "polinomio.h"

const char * tab = "\t";

using namespace std;
double func(double x)
{
  return exp(-x*x);
  //return 1.0 / (1+25*x*x);
}

int main()
{
  ofstream outfile;
  const char * filename = "interpolazione.data";
  const char * plot_cmd = "gnuplot -p interpolazione.gnu";
  int sys;

  const int n = 10;
  
  const int n_bins = 100;
  double x, y, y_cheb, y_equi;
  double xmin = -1.0 , xmax = 1.0 ;
  double dx = (xmax-xmin ) /n_bins;

  double err_cheb = 0.0 ,  err_equi = 0.0;

  Polinomio P(n), Q(n);

  // Interpola con nodi di Chebycev
  P.set_cheby_nodes();
  P.interp_newton(func);

  // Interpola con nodi Equispaziati
  Q.set_equi_nodes();
  Q.interp_newton(func);
  
  x = xmin;

  // Write file to plot
  outfile.open(filename);
  while (x<xmax)
  {
    err_cheb = 0.0;
    err_equi = 0.0;
    y = func(x);
    y_cheb = P.eval(x);
    y_equi = Q.eval(x);
    err_cheb += abs( y_cheb - y );
    err_equi += abs( y_equi - y );

    outfile
      <<x <<tab
      <<y <<tab
      <<y_cheb <<tab
      <<err_cheb <<tab
      <<y_equi <<tab
      <<err_equi <<tab
      <<endl;
  
    x = x+dx;
  }
  outfile.close();
  //  P.print_coeff();

  sys = system(plot_cmd);
  return 0;
}
