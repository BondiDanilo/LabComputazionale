//////////////////////////////////////////////////////////////////////
//                                                                  //
// This class contains the definitions of the states that can be    //
// used in the METROPOLIS algorithm in file 'MonteCarlo.h'          //
//                                                                  //
//////////////////////////////////////////////////////////////////////
//                                                                  //
// This class can be edited by the user, following these rules      //
//      - Member NAMES must remain the same, in order to avoid      //
//        conflict with functions in file "MonteCarlo.h"            //
//      - Only public members are called in "MonteCarlo.h",         //
//        so it is important not to change their structure          //
//        (e.g. arguments, ...). What each function actually do     //
//        is completely up to the user and it should not give       //
//        problems.                                                 //
//                                                                  //
//////////////////////////////////////////////////////////////////////

#ifndef STATE
#define STATE
#include <vector>
#include <random>
#include <iostream>

// This defines the type of the variables of the system.
// It can be edited by the user to match the system requirements.
typedef double type;

// This will depend on the system in consideration
class State
{
 //////////////////////////////////////////////////
 // User can ONLY edit:                          //
 //   - the type of '_variables'                 //
 //   - the definition of 'get_probability()'    //
 //   - the 'randomize' function                 //
 // to match the desired sistem                  //
 //////////////////////////////////////////////////
  
 private:
  // GENERAL: DO NOT EDIT
  type ** _variables;
  int _size1, _size2;

  // CASE SPECIFIC
  /* Code */
  
 //////////////////////////////////////////////////
 //           DO NOT EDIT THESE                  //
 //////////////////////////////////////////////////
 public:
  State();
  State(int,int); //
  State(type** variables);

  State operator = (State);
  //State operator + (State);
  void copy(State*);

  ////////// GENERAL: DO NOT CHANGE NAMES //////////
  // Initialization
  void initialize(); //
  void set_size(int,int);//
  int get_size();
  int get_size(int);
  type** get_variables();

  // Probability
  double get_probability(State*, std::vector <double>*); //
  void randomize(); //
  void randomize(int,int); //
  void randomize_single_element(); //

  //////////////////// Specific ////////////////////
  /* Code */
};

//////////////////////////////////////////////////////////////////////
//    Probability to transition from current state to a new state   //
//////////////////////////////////////////////////////////////////////
double State::get_probability(State * new_state, std::vector <double> * parameters)
{
  double p = 0.0;
  std::cout
    <<"Function 'get_probability(State*,std:;vector<double>)' "
    <<"to be defined by the user in file 'State.h'" <<std::endl;
  return p;
}

//////////////////////////////////////////////////////////////////////
//                         Constructors                             //
//////////////////////////////////////////////////////////////////////
State::State()
{
  _size1 = 1;
  _size2 = 1;
  _variables = new type*[_size1];
  for (int i = 0; i<_size1; i++)
    _variables[i] = new type[_size2];
}

State::State(int size1, int size2)
{
  _size1 = size1;
  _size2 = size2;
  _variables = new type*[_size1];
  for (int i = 0; i<_size1; i++)
    _variables[i] = new type[_size2];
  this->initialize();
}

// Initialization of the state: set all spins to 1
void State::initialize()
{
  std::cout
    <<"Function 'initialize() '"
    <<"to be defined by the user in file 'State.h'" <<std::endl;
  for (int i = 0 ; i < _size1 ; i++)
    for (int j = 0 ; j < _size2 ; j++)
      _variables[i][j] = 0.;
  return;
}

//////////////////////////////////////////////////////////////////////
//                        Randomizers                               //
//////////////////////////////////////////////////////////////////////
// Method 1: Randomize single element
void State::randomize_single_element()
{
  int i,j;
  i = rand()%_size1;
  j = rand()%_size2;
  this->randomize(i,j);
  return;
}

//Method 2: Randomize whole state
void State::randomize()
{
  for(int i=0;i<_size1;i++)
    for(int j=0;j<_size2;j++)
      if(rand()%2==0)
	this->randomize(i,j);
  return;
}

void State::randomize(int index1, int index2)
{
  std::cout
    <<"Function 'randomize(int,int)' "
    <<"to be defined by the user in file 'State.h'" <<std::endl;
  return;
}

//////////////////////////////////////////////////////////////////////
//                       Generic functions                          //
//////////////////////////////////////////////////////////////////////
void State::set_size(int size1,int size2)
{
  _size1 = size1;
  _size2 = size2;
  _variables = new type*[_size1];
  for (int i = 0; i<_size1; i++)
    _variables[i] = new type[_size2];
  return;
}

int State::get_size()
{
  return _size1*_size2;
}

int State::get_size(int index)
{
  int size;
  switch(index)
  {
  case 0:
    size = _size1*_size2;
    break;
  case 1:
    size = _size1;
    break;
  case 2:
    size = _size2;
    break;
  }
  return size;
}

type ** State::get_variables()
{
  return this->_variables;
}

State State::operator=(State a_state)
{
  this->_variables = a_state._variables;
  this->_size1 = a_state._size1;
  this->_size2 = a_state._size2;
  return *this;
}

void State::copy(State* old_state)
{
  _size1 = old_state->get_size(1);
  _size2 = old_state->get_size(2);
  for(int i = 0 ; i < _size1 ; i++)
    for(int j = 0 ; j < _size2 ; j++)
      _variables[i][j] = old_state->_variables[i][j];
}

//////////////////////////////////////////////////////////////////////
//                 Case specific functions                          //
//////////////////////////////////////////////////////////////////////

// Here the user can add more functions, specific tho the case study
#endif
