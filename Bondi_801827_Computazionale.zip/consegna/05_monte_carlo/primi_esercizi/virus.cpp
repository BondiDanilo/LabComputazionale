#include <iostream>
#include <stdlib.h>     /* srand, rand */
#include <time.h>       /* time */
#include <fstream>
#include <string>
#include <cmath>
#include <vector>
using namespace std;

const int Nx = 10;
const int Ny = 10;
const int nPeople = Nx*Ny;
const double pInfect = 0.3;

double random_number()
{
  return (double)rand()/RAND_MAX;
}

class lattice{
public:
  // Constructors
  lattice();
  lattice(int,int);
  // Members
  bool status[Nx][Ny];
  int nInfects;
  // Functions
  void Infect(int, int);
  void Heal(int, int);
  void CountInfects();
  void SpreadInfection();
};

void lattice::SpreadInfection()
{
  double r,r1,r2,r3,r4;
  for (int i = 1;i<Nx; i++)
    for (int j=1 ; j<Ny ;j++)
      if( status[i][j] == 1)
      {
	if( i < Nx-1 )
	{
	  r1 = random_number();
	  if ( r1 <= pInfect )
	    status[i+1][j] = 1;
	}
	
	if( i > 0 )
	{
	  r2 = random_number();
	  if ( r2 <= pInfect )      
	    status[i-1][j] = 1;
	}

	if( j < Ny-1 )
	{
	  r3 = random_number();
	  if ( r3 <= pInfect )	
	    status[i][j+1] = 1;
	}

	if( j > 0 )
	{
	  r4 = random_number();
	  if ( r4 <= pInfect )	
	    status[i][j-1] = 1;
	}
      }  
	
  return;
}

lattice::lattice(int n, int m)
// Initialize all to zero, exept element (n.m) which is one
{
  for(int i=0;i<Nx;i++)
    for(int j=0;j<Ny;j++)
      status[i][j] = 0;
  status[n][m] = 1;
}

void lattice::CountInfects()
{
  this->nInfects = 0;
  for(int i=0;i<Nx;i++)
    for(int j=0;j<Ny;j++)
      if (this->status[i][j] == 1)
	this->nInfects++;
  return;
}

lattice::lattice()
// Initialize all to zero
{
  for(int i=0;i<Nx;i++)
    for(int j=0;j<Ny;j++)
      status[i][j] = 0;
}

void lattice::Infect(int i, int j)
{
  this->status[i][j] = 1;
}

void lattice::Heal(int i, int j)
{
  this->status[i][j] = 0;
}

int main(){
  string filename = "virus.data";
  const char *  plotcmd = "gnuplot -p virus.gnu";
  int sys;
  
  int nDays = 30;
  int nInfYest, nInfToday;
  
  double r;
  
  ofstream outputFile;		       
  srand (time(NULL));
  outputFile.open(filename);
 
  // Set patient zero  
  lattice infection( rand()%Nx , rand()%Ny );
  
  for (int t = 1; t<nDays; t++)
  {
    nInfYest = infection.nInfects;
    infection.SpreadInfection();
    infection.CountInfects();
    nInfToday = infection.nInfects;
    outputFile << t <<" " <<nInfToday <<" " <<nInfToday-nInfYest <<endl;
  }
  sys = system(plotcmd);

  return 0;
}
