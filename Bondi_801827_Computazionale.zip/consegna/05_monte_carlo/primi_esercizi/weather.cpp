#include <iostream>
#include <stdlib.h>     /* srand, rand */
#include <time.h>       /* time */
#include <fstream>
#include <string>
#include <cmath>

using namespace std;
int main(){
  string filename = "weather.data";
  const char *  plotcmd = "gnuplot -p weather.gnu";
  int sys;
  
  int nDays = 2*365;
  int nSunny = 0;
  
  double pSS,pSR,pRS,pRR;
  double r;

  bool weather = 0;

  //Probabilities
  pSS = 0.9;       // Sunny -> Sunny
  pSR = 1-pSS;     // Sunny -> Rainy
  pRS = 0.5;       // Rainy -> Sunny
  pRR = 1-pRS;     // Rainy -> Rainy
  
  ofstream outputFile;		       
  srand (time(NULL));
  outputFile.open(filename);
  
  for (int t = 1; t<nDays; t++)
  {
    r = (double) rand()/RAND_MAX;
    if(weather == 1)
    {
      if(r <= pSS)     // Sunny -> Sunny
      {
	// Don't change state
	// Increment sunny days
	nSunny++;
      }
      else             // Sunny -> Rainy
      {
	// Change state
	weather = 0;
      }
    }
    else if (weather == 0)
    {      
      if(r <= pRR)     // Rainy -> Rainy
      {
	// Don't change state
      }
      else             // Rainy -> Sunny
      {
	// Change state
	weather = 1;
	// Increment sunny days
	nSunny++;
      }
    }

    outputFile << t << " " <<(double) nSunny/t <<endl;
  }
  sys = system(plotcmd);

  return 0;
}
