#include <iostream>
#include <stdlib.h>     /* srand, rand */
#include <time.h>       /* time */
#include <fstream>
#include <string>
#include <cmath>

using namespace std;
int main(){
  string filename;
  const char *  plotcmd = "gnuplot -p nuclear-decay.gnu";
  int sys;
  
  int N0 = 100;     // Initial number of atoms
  int N, ntemp;
  
  double decayTime = 0.8;
  double dt = 0.01;
  double timeMax = decayTime * 2;
  double timeNow;
  int t = 0;
  int n_measure = timeMax/dt;
  
  double probDecay = (1.0/decayTime);
  double r;
  double error = 0.0;

  filename = "nuclear-decay.data";
  ofstream outputFile;		       
  srand (time(NULL));

  outputFile.open(filename);

  N = N0;
  ntemp = N;
  timeNow =0.0;
  outputFile << timeNow<<" "<<N <<" " <<N0 <<endl;

  while(timeNow < timeMax)
  {
    for (int n = 1; n<N;n++)
    {
      r = (double) rand()/RAND_MAX;
      if (r<=probDecay/N0)
	ntemp--;
    }
    N = ntemp;
    error += pow(N-N0*exp(-timeNow/decayTime),2);
    outputFile <<timeNow <<" "<<N <<" " <<N0*exp(-timeNow/decayTime) <<endl;
    timeNow = timeNow + dt;
  }
  error = sqrt(error/n_measure);
  cout <<"Error: "<<error <<endl;
  sys = system(plotcmd);

  return 0;
}
