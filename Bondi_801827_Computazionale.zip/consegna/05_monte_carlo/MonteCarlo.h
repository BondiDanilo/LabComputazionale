//////////////////////////////////////////////////////////////////////
//                                                                  //
// GENERIC CLASSES AND METHODS TO IMPLEMENT  METROPOLIS ALGORITHM   //
//                                                                  //
//////////////////////////////////////////////////////////////////////
//                                                                  //
// in file "State.h" is contained the class "State" which is to be  //
// edited specifically for the desired system (i.e. Ising Lattice,  //
// gas of particles, integration of a function,...)                 //
//                                                                  //
// Private members of "State" will differ from case to case, but    //
// all PUBLIC MEMBERS NAMES shall remain the same (definitions and  //
// types can be edited as needed) in order to avoid conflicts with  //
// the functions in this file                                       //
//                                                                  //
//////////////////////////////////////////////////////////////////////

#ifndef MONTECARLO
#define MONTECARLO
#include <vector>
#include <iostream>
#include <random>
#include "State.h"
using namespace std;

double random_number()
{
  return (double) rand()/RAND_MAX;
};

//////////////////////////////////////////////////////////////////////
//                             STATE                                //
//////////////////////////////////////////////////////////////////////

// Update t_index-th element of the chain
void Metropolis( State * old_state, int method, vector <double> * parameters )
{
  double p_acc,r;
  
  int size1, size2;  
  size1 = old_state->get_size(1);
  size2 = old_state->get_size(2);

  State * new_state = new State(size1,size2);
  new_state->copy(old_state);
  
  //////////////////////////////////////////////////
  // Propose a new state (Depending on 'method')  //
  // with probability defined in class 'State'    //
  //    e.g. Boltzmann                            //
  //////////////////////////////////////////////////
  
  // Method 1: evolving one random particle at time
  if (method == 1)
    new_state->randomize_single_element();
  // Method 2: evolving the entire system at once
  else if (method == 2)
    new_state->randomize();
  // If input is wrong, print error message
  else
  {
    std::cout <<"ERROR: In function 'void Metropolis(State, int index, int method)'" <<std::endl
	 <<"please provide a valid argument (1,2) for 'method'" <<std::endl;
    return;
  }

  // Calculate probability
  p_acc = old_state->get_probability(new_state,parameters);

  if (p_acc >= 1)
    p_acc = 1;
  if (p_acc < 1e-5) // Cutoff for small numbers
    {
      p_acc = 0;
    }
  // Update the state with probability 'p_acc'
  r = random_number();
  if ( r <= p_acc )
  {
    *old_state = *new_state;
  }
  // Else, keep the old state
  delete new_state;
}

void Metropolis(State * old_state, vector<double> * parameters)
{
  // Default Method set to 2
  Metropolis(old_state,2,parameters);
  return;
}

void Metropolis(State * old_state)
{
  // Parameters is set by default to a 1-component vector
  // Default Method set to 2
  vector<double> * parameters = new vector<double>;
  parameters->push_back(0.);  
  Metropolis(old_state,2,parameters);
  return;
}

#endif
