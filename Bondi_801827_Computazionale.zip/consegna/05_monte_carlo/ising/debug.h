#ifndef DEBUG
#define DEBUG

#include <vector>
#include <iostream>
using namespace std;

 void test(int n)
{
  cout << "Test " <<n <<endl;  
  return;
}

void print(string text)
{
  cout <<text <<endl;
  return;
}

void print(double x)
{
  cout <<x <<endl;
  return;
}

void print(int n)
{
  cout <<n <<endl;
  return;
}

void printVector(vector <double> vec)
{
  for (int i=0;i<vec.size();i++)
    cout <<vec[i] <<endl;
  return;
}

void printVector(vector <double>* vec)
{
  for (int i=0;i<vec->size();i++)
    cout << vec->at(i) <<endl;
  return;
}

#endif
