// c++ ising.cpp $(root-config --cflags --glibs)

#include <iostream>
#include <cstdlib>
#include <cmath>
#include <time.h>
#include <stdlib.h>
#include <vector>
#include "libreria.h"

#include <TGraph.h>  
#include <TCanvas.h>
#include <TStyle.h>
#include <TAxis.h>

using namespace std;


void MetroHastings (System * old_state,int method) {
  double beta = 1./old_state->ReturnTemperature(); // Kb = 1
  //cout << beta << endl;
  System new_state(old_state);
  double p,old_pot,new_pot,new_bolt,old_bolt,r;
  if (method==1) {
    int sx = rand()%new_state.ReturnIndeX();
    int sy = rand()%new_state.ReturnIndeY();
    //cout << sx << "  " << sy << endl;
    //cout << "states" << old_state->particles[sx][sy].spin << "  " ; 
    new_state.particles[sx][sy].spin *= -1; // flip sign
    //cout << new_state.particles[sx][sy].spin << "  " << endl;
    old_pot = old_state->CloseEnergy(sx,sy);
    new_pot = new_state.CloseEnergy(sx,sy);
    //cout << "pot " << old_pot << "  " << new_pot << endl;
    new_bolt = exp(-beta*new_pot);
    old_bolt = exp(-beta*old_pot);
    p = new_bolt/old_bolt;
    r = (double)rand()/RAND_MAX;
    //cout << "p= " << p << " r= " << r<<endl;

    if (r<=p) {
      *old_state=new_state;
      //cout << old_state->particles[sx][sy].spin << endl;
    }
  }
	
  else {
    double jx,jy;
    for (int ix=0;ix<old_state->ReturnIndeX();ix++) {
      for(int iy=0;iy<old_state->ReturnIndeY();iy++) {
	new_state.particles[ix][iy].spin *= -1;
	new_pot = new_state.CloseEnergy(ix,iy);
	old_pot = old_state->CloseEnergy(ix,iy);
	old_bolt = exp(-beta*old_pot);
	new_bolt = exp(-beta*new_pot);
	p = new_bolt/old_bolt; 	
	r = (double)rand()/RAND_MAX;
	if(r>p) {
	  new_state.particles[ix][iy].spin *= -1;
	}
			
      }
    }
    double new_energy = new_state.ComputeEnergy();
    double old_energy = old_state->ReturnEnergy();
    old_bolt = exp(-beta*old_energy);
    new_bolt = exp(-beta*new_energy);
    p = new_bolt/old_bolt;
    r = (double)rand()/RAND_MAX;
    if (r<=p) {
      *old_state = new_state;
    }
		
  }
}

double mean (vector<double> V) {
  double sum = 0;
  for (int i=0;i<V.size();i++) {
    sum += V[i];	
	
  }
  sum = sum/V.size();
  return sum;
}

double mean_sq (vector<double> V) {
  double sum = 0;
  for (int i=0;i<V.size();i++) {
    sum += V[i]*V[i];	
	
  }
  sum = sum/V.size();
  return sum;
}


int main () {


  srand (time(NULL));
  System *lattice = new System (0.3,20,20);
    vector<double> M;
    int counterPlus =0;
    int counterMinus =0;
    for (int i=0;i<lattice->ReturnIndeX();i++) {
    for (int j=0;j<lattice->ReturnIndeY();j++) {
    //cout << i << "  "  << j << "    " << lattice->particles[i][j].spin << endl;
    if (lattice->particles[i][j].spin==1) {
    counterPlus += 1;
    }
    else {
    counterMinus += 1;
		
    }

    }

    }
    cout << "COUNTER " << counterPlus << " " << counterMinus <<"  m= " << lattice->magnetization() << endl;
    for (int i=0;i<500000;i++) {
    MetroHastings(lattice,1);
    if (i>100000) {
    M.push_back(lattice->magnetization());
    }

    }
    counterPlus =0;
    counterMinus =0;
    for (int i=0;i<lattice->ReturnIndeX();i++) {
    for (int j=0;j<lattice->ReturnIndeY();j++) {
    //cout << i << "  "  << j << "    " << lattice->particles[i][j].spin << endl;
    if (lattice->particles[i][j].spin==1) {
    counterPlus += 1;
    }
    else {
    counterMinus += 1;
		
    }

    }

    }
    cout << counterPlus << "  " << counterMinus <<"  m= " << mean(M) <<  endl;

  TGraph magnetization;
  TGraph err_m;
  vector<double> M;
  int N = 100000;
  double m;
  double err;
  double Temp = 0.8;
  System *lattice = new System (Temp,20,20);

  for(int j=0;j<20;j++) {
    for (int i=0;i<N;i++) {
      MetroHastings(lattice,0);
      if (i>0.5*N) {
	M.push_back(lattice->magnetization());
      }

    }
    m = mean(M);
    err = sqrt((mean_sq(M)-m*m)/N);
    cout << "M= " << m << endl;
    cout << "errM= " << err << endl;
        magnetization.SetPoint(j,Temp,m);
        err_m.SetPoint(j,Temp,err);
    lattice->Randomize();
    M.clear();
    Temp += 0.2;
    lattice->SetT(Temp);

  }

  TCanvas mycanv ("canv","canv");
  magnetization.SetMarkerStyle(21);
  magnetization.GetXaxis()->SetTitle("Temp");
  magnetization.GetYaxis()->SetTitle("M");
  magnetization.SetMarkerSize(0.6);
  magnetization.Draw("AP");
  mycanv.Print("magnetization.png","png");

  TCanvas mycanv2 ("canv2","canv2");
  err_m.SetMarkerStyle(21);
  err_m.GetXaxis()->SetTitle("Temp");
  err_m.GetYaxis()->SetTitle("errM");
  err_m.SetMarkerSize(0.6);
  err_m.SetMarkerColor(kRed);
  err_m.Draw("AP");
  mycanv2.Print("errM.png","png");





	
  return 0;

}
