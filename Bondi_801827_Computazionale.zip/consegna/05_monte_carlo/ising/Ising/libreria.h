#ifndef libreria_h
#define libreria_h
#include <vector>


using namespace std;

struct vecI_2d {

	int nx;
	int ny;

};

struct vecD_2d {
	double x;
	double y;

};

struct atom {

	double spin; // 0,1,-1
};


class System {
	double T;
	int i,j;
	double energy;
	double J = -1;
	public:
	atom particles[20][20];	
	//System();	
	System(System * old_state);
	System (double T, int ix,int iy);
	void number_particle (int n);
	void SetT (double Temp);
	void Randomize ();
	double ComputeEnergy();
	double ReturnTemperature();
	double ReturnEnergy();
	double CloseEnergy(int ix,int iy);
	double magnetization();
	int ReturnIndeX();
	int ReturnIndeY();
	//void MetroHastings(System * old_state, int method);
};

#endif
