#include "libreria.h"      
#include <iostream>
#include <cstdlib>
#include <cmath>
#include <time.h>
#include <stdlib.h>

using namespace std;



System::System(System * old_state) {
	T = old_state->ReturnTemperature();
	i = old_state->ReturnIndeX();
	j = old_state->ReturnIndeY();
	for (int kx=0;kx<i;kx++) { 
		for(int ky=0;ky<j;ky++) {
			particles[kx][ky].spin = old_state->particles[kx][ky].spin;
		}
	}
	double sum =0;
	int jx,jy;
	for (int kx=0;kx<i;kx++) { // ogni interazione viene contata due volte, quindi ogni volta la conto la metà
		for(int ky=0;ky<j;ky++) {
			for (int nTeta=0;nTeta<2;nTeta++) {
				jx = kx + cos(nTeta*M_PI/2);
				jy = ky + sin(nTeta*M_PI/2);
				if (0<=jx && jx<i) {
					if (0<=jy && jy<j) {
						sum += -J*particles[kx][ky].spin*particles[jx][jy].spin;	
					}
				}
			}

		}
	}
	energy = sum;
}


System::System(double Temp, int sx, int sy) {
	i=sx;
	j=sy;
	T = Temp;
	int r;
	/*particles = new atom *[i];
	for (int k=0;k<i;k++) {
		particles[k] = new atom[j];
	}*/
	for (int kx=0;kx<i;kx++) { 
		for(int ky=0;ky<j;ky++) {
			r = rand()%2;
			if (r==1) {
				//cout << "eccomi" << endl;
				particles[kx][ky].spin =1;
				}
			else {
				particles[kx][ky].spin = -1;
			} 
		}
	}
	double sum =0;
	int jx,jy;
	for (int kx=0;kx<i;kx++) { // ogni interazione viene contata due volte, quindi ogni volta la conto la metà
		for(int ky=0;ky<j;ky++) {
			for (int nTeta=0;nTeta<2;nTeta++) {
				jx = kx + cos(nTeta*M_PI/2);
				jy = ky + sin(nTeta*M_PI/2);
				if (0<=jx && jx<i) {
					if (0<=jy && jy<j) {
						sum += -J*particles[kx][ky].spin*particles[jx][jy].spin;	
					}
				}
			}

		}
	}
	energy = sum;
}


double System::ComputeEnergy() {
	double sum =0;
	int jx,jy;
	for (int kx=0;kx<i;kx++) { 
		for(int ky=0;ky<j;ky++) {
			for (int nTeta=0;nTeta<2;nTeta++) { // conto solo una volta ogni interazione
				jx = kx + cos(nTeta*M_PI/2);
				jy = ky + sin(nTeta*M_PI/2);
				if (0<=jx && jx<i) {
					if (0<=jy && jy<j) {
						sum += -J*particles[kx][ky].spin*particles[jx][jy].spin;	
					}
				}
			}

		}
	}
	energy = sum;
	return energy;
}

double System::CloseEnergy (int ix,int iy) 
{
	double teta;
	int jx,jy;
	double sum = 0;
	for (int k=0;k<4;k++) {
		teta = k*M_PI/2;
		jx = ix + cos(teta);
		jy = iy + sin(teta);
		//cout << jx << "  " << jy <<"  " <<  i << "  " << j << endl;	
		if(0<=jx && jx<i) {
			if(0<=jy && jy<j) {
				sum += -J*particles[ix][iy].spin*particles[jx][jy].spin;
				//cout << particles[ix][iy].spin << "  " << particles[jx][jy].spin << endl;
			}
		}
	}
	return sum;	
}

double System::ReturnEnergy ()
{
	return energy;
}


double System::magnetization ()
{
	double sum =0;
	int jx,jy;
	for (int kx=0;kx<i;kx++) { 
		for(int ky=0;ky<j;ky++) {
			/*for (int nTeta=0;nTeta<2;nTeta++) { // conto solo una volta ogni interazione
				jx = kx + cos(nTeta*M_PI/2);
				jy = ky + sin(nTeta*M_PI/2);
				if (0<=jx && jx<i) {
					if (0<=jy && jy<j) {
						sum += particles[kx][ky].spin*particles[jx][jy].spin;	
					}
				}

			}*/
		sum += particles[kx][ky].spin;
		}
	 }
	return abs(sum/(i*j));
}

double System::ReturnTemperature() 
{
	return T;
}

int System::ReturnIndeX() {

	return i;
}



int System::ReturnIndeY() {

	return j;
}

void System::SetT (double Temp) {

	T = Temp;

}

void System::Randomize () {
	int r;
	for (int kx=0;kx<i;kx++) { 
		for(int ky=0;ky<j;ky++) {
			r = rand()%2;
			if (r==1) {
				particles[kx][ky].spin = 1;
				}
			else {
				particles[kx][ky].spin = -1;
			} 
		}
	}
	double sum =0;
	int jx,jy;
	for (int kx=0;kx<i;kx++) { // ogni interazione viene contata due volte, quindi ogni volta la conto la metà
		for(int ky=0;ky<j;ky++) {
			for (int nTeta=0;nTeta<2;nTeta++) {
				jx = kx + cos(nTeta*M_PI/2);
				jy = ky + sin(nTeta*M_PI/2);
				if (0<=jx && jx<i) {
					if (0<=jy && jy<j) {
						sum += -J*particles[kx][ky].spin*particles[jx][jy].spin;	
					}
				}
			}

		}
	}
	energy = sum;
}

