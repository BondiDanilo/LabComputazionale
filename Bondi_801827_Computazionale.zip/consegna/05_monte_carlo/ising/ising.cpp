#include <iostream>
#include <fstream>
#include <string>
#include <ctime>
#include <cmath>
#include "MonteCarlo.h"

using namespace std;

int main()
{
  srand(time(NULL));
  // Plot
  const char * plot_cmd = "gnuplot -p ising.gnu";
  string filename = "ising.data";
  int sys_cmd;
  ofstream out_file;
  string tab ="\t";

  // Evolution
  int n        = 20;
  int n_steps  = 100;
  int n_repeat = 1;

  // Thermodynamics
  double J_magn = 1.;
  double temperature;
  vector <double> * parameters = new vector<double>;
  parameters->resize(2);
  // In this case the vector parameters does nothing, it is just for syntax
  
  double incr_temperature = 0.1;
  double min_temperature  = 0.01;
  double max_temperature  = 6. ;

  // Measures
  double mag1    = 0., mag2    = 0.;
  double sq_mag1 = 0., sq_mag2 = 0.;
  double err1        , err2        ;

  // System
  State * mc_ising1 = new State(n,n);  // Method 1
  State * mc_ising2 = new State(n,n);  // Method 2

  // Open output file
  out_file.open(filename);

  // Set J
  mc_ising1->set_J(J_magn);
  mc_ising2->set_J(J_magn);

  // Loop on temperature
  temperature = min_temperature;

  while (temperature < max_temperature)
  {
    // Setting parameters
    mc_ising1->set_temperature(temperature);
    mc_ising2->set_temperature(temperature);

    //////////////////////////////
    //        Main Loop         //
    //////////////////////////////

    // Loop on time steps
    for (int t = 0; t < n_steps; t++)
      {
	// Method 1: Flip one spin at a time
	for (int i = 0; i<n_repeat;i++)
	  Metropolis(mc_ising1,1,parameters);
	mc_ising1 -> set_magnetization();
	mag1 += mc_ising1 -> get_magnetization();
	sq_mag1 += mag1*mag1;

	// Method 2: Flip all spins at once
	Metropolis(mc_ising2,2,parameters);
	mc_ising2 -> set_magnetization();
	mag2    += mc_ising2 -> get_magnetization();
	sq_mag2 += mag2*mag2;
      }
    
    // Now we have the magnetization of the final step_avg states
    // We want the average magnetization
    // Calculate error
    mag1    /= (n_steps);
    sq_mag1 /= (n_steps);
    mag2    /= (n_steps);
    sq_mag2 /= (n_steps);
    
    err1 = sqrt( (mag1*mag1 - sq_mag1/n_steps) / (n_steps -1) ) ;
    err2 = sqrt( (mag2*mag2 - sq_mag2/n_steps) / (n_steps -1) ) ;
    
    // Write to file: temperature, mag1, err1, mag2, err2
    out_file
      << temperature <<tab
      << mag1 <<tab << err1 <<tab
      << mag2 <<tab << err2 <<tab
      << endl;
    // End loop on temperature
    temperature += incr_temperature;
  }
  
  out_file.close();
  // Plot
  sys_cmd = system(plot_cmd);
  return 0;
}
