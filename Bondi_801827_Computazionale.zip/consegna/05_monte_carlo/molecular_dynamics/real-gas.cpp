#include <cmath>
#include "MonteCarlo.h"
#include "include/constants.h"
#include "include/initialization.h"

#include "debug.h"
using namespace std;

int main()
{
  srand(time(NULL));
  int sys_cmd;
  // Plot
  const char * plot_pv = "gnuplot -p pv.gnu";
  const string file = "real-gas.data";

  ofstream out_file;

  // Loop constants
  int init_cell;  // Number of particles per side
  int n_steps;  
  int n_equil;  
  int n_measures;

  int n_series = 4;
  int n_points = 10;

  // Loop variables
  double min_temperature ; 
  double max_temperature ; 
  double incr_temperature = (max_temperature-min_temperature) / n_series;
  
  double min_density  = .01;
  double max_density  = .1 ;
  double incr_density = (max_density-min_density) / n_points;

  // Measures
  double t_pressure, s_pressure, ss_pressure; // Accumulation
  double pressure, err_pressure;
  double t_energy, s_energy, ss_energy;
  double energy, err_energy;
  double t_fmp, s_fmp, ss_fmp;
  double fmp, err_fmp;

  //////////////////////////////////////////////////
  //             Initialize System                //
  //////////////////////////////////////////////////

  init_cell = 6;

  n_steps = 5000;
  n_equil = 5000;
  n_measures = n_steps / stepAvg;

  min_temperature = 0.8;
  max_temperature = 3.5;
  
  incr_temperature = (max_temperature - min_temperature)/n_series;

  min_density = 0.1;
  max_density = 0.4;
  incr_density = (max_density - min_density)/n_points;
  
  temperature = min_temperature;
  density = min_density;

  out_file.open(file);  
  while (temperature <= max_temperature)
  {
    // Initialize parameters
    InitializeSystem(init_cell, temperature, density);
  
    // System
    State * gas = new State(nAtom,7);
  
    //////////////////////////////////////////////////
    //          Perfect Gas - PV curves             //
    //////////////////////////////////////////////////

    cout <<"Temperature " <<temperature <<"/" <<max_temperature <<endl;
    cout <<"Progress: " <<endl; 
    out_file <<"# Temperature | Volume/N | Pressure | errPressure " <<endl;
    while (density <= max_density) // Reset density to 'min_density' at the end
    {
      cout <<100*density/max_density <<"%" <<endl;

      // Set Parameters
      InitializeSystem(init_cell,temperature,density);
      gas->initialize();

      // Equilibrium Loop
      for (int t = 0; t < n_equil; t++)
	Metropolis(gas);

      // Measure Loop      
      s_pressure = 0. ;
      ss_pressure = 0. ;

      for (int t = 0; t < n_steps; t++)
      {
	// Evolve
	Metropolis(gas);
	// Measure Pressure
	gas->measure();
	t_pressure = gas->get_pressure();
	s_pressure += t_pressure;
	
	// Measure each 'stepAvg' steps
	if( t % stepAvg == 0 )
	{
	  s_pressure = s_pressure / stepAvg;
	  pressure += s_pressure;
	  ss_pressure += pressure*pressure;
	  s_pressure = 0.;
	}
      }

      // Calculate averages and error
      pressure = pressure / n_measures;
      err_pressure = (ss_pressure/n_measures - pressure*pressure) / n_measures;
      err_pressure = sqrt( abs( err_pressure ) );
      
      // Write to file
      out_file
	<< temperature <<tab
	<< 1./density <<tab
	<< pressure <<tab
	<< err_pressure <<tab
	<<endl;
      density += incr_density;
    }
	
    temperature += incr_temperature;
    density = min_density;
    out_file <<endl <<endl;
    cout <<endl <<endl;
    
    delete gas;
  }
  out_file.close();
  
  // Plots
  sys_cmd = system(plot_pv);

  return 0;
}
