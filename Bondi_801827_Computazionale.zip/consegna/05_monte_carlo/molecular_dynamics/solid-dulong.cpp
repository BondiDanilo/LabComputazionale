#include <iostream>
#include <fstream>
#include <cmath>
#include "MonteCarlo.h"
#include "include/constants.h"
#include "include/initialization.h"

#include "debug.h"
using namespace std;

int main()
{
  srand(time(NULL));
  int sys_cmd;
  // Plot
  const char * plot_cmd = "gnuplot -p solid-dulong.gnu";
  const string file = "solid-dulong.data";

    ofstream out_file;

  // Loop constants
  int init_cell = 4;
  int n_steps  = 7000;
  int n_equil  = 7000;
  int n_measures;

  int n_series = 5;
  int n_points = 10;

  // Loop variables
  double min_temperature  = 1.;
  double max_temperature  = 3. ;
  double incr_temperature = (max_temperature-min_temperature) / n_series;
  
  // Measures
  double t_energy, s_energy, ss_energy;
  double energy, err_energy;
 
  temperature = 2.0;
  density = .5;
  
  fcc = 0; // Set lattice to a FCC type
  
  // Initialize parameters
  InitializeSystem(init_cell, 1.0, 1.0);
  
  // System
  State * solid = new State(nAtom,7);
  State * initial_state = new State(nAtom,7);
 
  //////////////////////////////////////////////////
  //         2. Solid - Dulong-Petit Law          //
  //////////////////////////////////////////////////
  out_file.open(file);

  n_steps = 10000;
  n_equil = 100000;
  n_measures = n_steps / stepAvg;

  min_temperature = 0.0001;
  max_temperature = 0.5;
  incr_temperature = (max_temperature - min_temperature)/n_points;
  
  temperature = min_temperature;
  density = 0.1;
  incr_temperature = 1.0
  
  out_file <<"# Temperature | Energy | errEnergy " <<endl;  
  while (temperature < max_temperature)
  {
    cout << 100*temperature/max_temperature <<"%" <<endl;

    // Set Parameters
    InitializeSystem(init_cell,temperature,density);
    solid->initialize();

    // Equilibrium Loop
    for (int t = 0; t < n_equil; t++)
    {  
      Metropolis(solid);
      if(t % stepAvg/10 == 0)
      {	  
	solid->fix_zero_pressure();
	s_energy = s_energy / stepAvg;
      }
    }
    // Measure Loop      
    s_energy = 0. ;
    ss_energy = 0. ;

    for (int t = 0; t < n_steps; t++)
    {
      // Evolve
      Metropolis(solid);
      // Measure Energy
      solid->measure();

      t_energy = solid->get_energy();
      s_energy += t_energy;

      // Measure each 'stepAvg' steps
      if( t % stepAvg == 0 )
	{
	  cout << solid->get_pressure() <<endl;
	  energy += s_energy;
	  ss_energy += energy*energy;
	  s_energy = 0.;
	}
    }

    // Calculate averages and error

    energy = energy / n_measures;
    err_energy = (ss_energy/n_measures - energy*energy) / n_measures;
    err_energy = sqrt( abs( err_energy ) );
      
    // Write to file
    out_file
      << temperature <<tab
      << energy <<tab
      << err_energy <<tab
      <<endl;
    
    temperature += incr_temperature;
  }
  out_file.close();    
  
  //////////////////////////////////////////////////////////////////////
  //////////////////////////////////////////////////////////////////////
  
  // Plots
  sys_cmd = system(plot_cmd);

  return 0;
}
