//////////////////////////////////////////////////////////////////////
//To Do: definition of energy in State::get_energy()
//////////////////////////////////////////////////////////////////////
#include <cmath>
#include "MonteCarlo.h"
#include "include/constants.h"
#include "include/initialization.h"

#include "debug.h"
using namespace std;

int main()
{
  srand(time(NULL));
  int sys_cmd;
  // Plot
  const char * plot_gas = "gnuplot -p gas.gnu";
  const char * plot_pv = "gnuplot -p pv.gnu";
  const char * plot_solid = "gnuplot -p solid.gnu";
  const char * plot_fmp = "gnuplot -p solid-fmp.gnu";

  const string file1 = "gas.data";
  const string file2 = "solid.data";
  const string file3 = "solid-fmp.data";

  ofstream out_file;

  // Loop constants
  int init_cell = 3;
  int n_steps  = 7000;
  int n_equil  = 7000;
  int n_measures;

  int n_series = 5;
  int n_points = 10;

  // Loop variables
  double min_temperature  = 1.;
  double max_temperature  = 3. ;
  double incr_temperature = (max_temperature-min_temperature) / n_series;
  
  double min_density  = .01;
  double max_density  = .1 ;
  double incr_density = (max_density-min_density) / n_points;

  
  // Program Section Switch
  int switch_section = 3;  

  // Measures
  double t_pressure, s_pressure, ss_pressure; // Accumulation
  double pressure, err_pressure;
  double t_energy, s_energy, ss_energy;
  double energy, err_energy;
  double t_fmp, s_fmp, ss_fmp;
  double fmp, err_fmp;

  temperature = 2.0;
  density = .5;

  // Initialize parameters
  InitializeSystem(init_cell, 1.0, 1.0);
  
  // System
  State * gas = new State(nAtom,7);
  State * solid = new State(nAtom,7);
  State * initial_state = new State(nAtom,7);
 
  //////////////////////////////////////////////////
  //          1. Real Gas - PV curves             //
  //////////////////////////////////////////////////
  if (switch_section == 0 || switch_section == 1)
  {  
    cout <<"/////////////////////////////////////////" <<endl
	 << "Gas" <<endl
	 <<"/////////////////////////////////////////" <<endl;
    out_file.open(file1);

    n_steps = 7000;
    n_equil = 7000;
    n_measures = n_steps / stepAvg;

    min_temperature = 0.5;
    max_temperature = 1.8;
    incr_temperature = (max_temperature - min_temperature)/n_points;

    min_density = 0.01;
    max_density = 0.7;
    incr_density = (max_density - min_density)/n_points;
  
    temperature = min_temperature;
    density = min_density;

    while (temperature <= max_temperature)
      {
	cout <<"Temperature " <<temperature <<"/" <<max_temperature <<endl;
	cout <<"Progress: " <<endl; 
	out_file <<"# Temperature | Volume/N | Pressure | errPressure " <<endl;
	while (density <= max_density) // Reset density to 'min_density' at the end
	  {
	    cout <<100*density/max_density <<"%" <<endl;
	    // Set Parameters
	    InitializeSystem(init_cell,temperature,density);
	    gas->initialize();

	    // Equilibrium Loop
	    for (int t = 0; t < n_equil; t++)
	      Metropolis(gas);

	    // Measure Loop      
	    s_pressure = 0. ;
	    ss_pressure = 0. ;

	    for (int t = 0; t < n_steps; t++)
	      {
		// Evolve
		Metropolis(gas);
		// Measure Pressure
		gas->measure();
		t_pressure = gas->get_pressure();
		s_pressure += t_pressure;

		// Measure each 'stepAvg' steps
		if( t % stepAvg == 0 )
		  {
		    s_pressure = s_pressure / stepAvg;
		    pressure += s_pressure;
		    ss_pressure += pressure*pressure;
		    s_pressure = 0.;
		  }
	      }

	    // Calculate averages and error
	    pressure = pressure / n_measures;
	    err_pressure = (ss_pressure/n_measures - pressure*pressure) / n_measures;
	    err_pressure = sqrt( abs( err_pressure ) );
      
	    // Write to file
	    out_file
	      << temperature <<tab
	      << 1./density <<tab
	      << pressure <<tab
	      << err_pressure <<tab
	      <<endl;
	    density += incr_density;
	  }
	
	temperature += incr_temperature;
	density = min_density;
	out_file <<endl <<endl;
	cout <<endl <<endl;
      }
    out_file.close();
  }
  //////////////////////////////////////////////////////////////////////
  //////////////////////////////////////////////////////////////////////

  //////////////////////////////////////////////////
  //         2. Solid - Dulong-Petit Law          //
  //////////////////////////////////////////////////
  if (switch_section == 2 || switch_section == 0)
  {
    cout <<"/////////////////////////////////////////" <<endl
	 << "Solid" <<endl
	 <<"/////////////////////////////////////////" <<endl;
    out_file.open(file2);

    fcc = 1;
    n_steps = 7000;
    n_equil = 7000;
    n_measures = n_steps / stepAvg;

    min_temperature = 0.2;
    max_temperature = 0.5;
    incr_temperature = (max_temperature - min_temperature)/n_points;
  
    temperature = min_temperature;
    density = 1.0;
  
    out_file <<"# Temperature | Energy | errEnergy | FMP | errFMP " <<endl;  
    while (temperature < max_temperature)
      {
	cout << 100*temperature/max_temperature <<"%" <<endl;
    
	// Set Parameters
	InitializeSystem(init_cell,temperature,density);
	solid->initialize();

	// Equilibrium Loop
	for (int t = 0; t < n_equil; t++)
	  Metropolis(solid);

	// Measure Loop      
	s_energy = 0. ;
	ss_energy = 0. ;
	s_fmp = 0. ;
	ss_fmp = 0. ;

	for (int t = 0; t < n_steps; t++)
	  {
	    // Evolve
	    Metropolis(solid);
	    // Measure Energy and FMP
	    solid->measure();
	    t_energy = solid->get_energy();
	    s_energy += t_energy;
	    t_fmp = solid->get_fmp(initial_state);
	    s_fmp += t_fmp;

	    // Measure each 'stepAvg' steps
	    if( t % stepAvg == 0 )
	      {
		s_energy = s_energy / stepAvg;
		s_fmp += s_fmp / stepAvg;
	  
		fmp += s_fmp;
		energy += s_energy;

		ss_energy += energy*energy;
		ss_fmp += fmp*fmp;
	  
		s_energy = 0.;
		s_fmp = 0.;
	      }
	  }

	// Calculate averages and error

	energy = energy / n_measures;
	err_energy = (ss_energy/n_measures - energy*energy) / n_measures;
	err_energy = sqrt( abs( err_energy ) );

	fmp = fmp / n_measures;
	err_fmp = (ss_fmp/n_measures - fmp*fmp) / n_measures;
	err_fmp = sqrt( abs( err_fmp ) );
      
	// Write to file
	out_file
	  << temperature <<tab
	  << energy <<tab
	  << err_energy <<tab
	  << fmp <<tab
	  << err_fmp <<tab
	  <<endl;
    
	temperature += incr_temperature;
      }
    out_file.close();  
  }
  
  //////////////////////////////////////////////////////////////////////
  //////////////////////////////////////////////////////////////////////
  //////////////////////////////////////////////////////////////////////
  //////////////////////////////////////////////////////////////////////

  //////////////////////////////////////////////////
  //         3. Solid - Phase Transition          //
  //////////////////////////////////////////////////
  if (switch_section == 3 || switch_section == 0)
  {
    cout <<"/////////////////////////////////////////" <<endl
	 << "Solid" <<endl
	 <<"/////////////////////////////////////////" <<endl;
    out_file.open(file3);

    fcc = 1;
    n_steps = 7000;
    n_equil = 7000;
    n_measures = n_steps / stepAvg;
    n_points = 30;

    min_temperature = 0.01;
    max_temperature = 2.5;
    incr_temperature = (max_temperature - min_temperature)/n_points;
  
    temperature = min_temperature;
    density = .5;
  
    out_file <<"# Temperature | Energy | errEnergy | FMP | errFMP " <<endl;  
    while (temperature < max_temperature)
      {
	cout << 100*temperature/max_temperature <<"%" <<endl;
    
	// Set Parameters
	InitializeSystem(init_cell,temperature,density);
	solid->initialize();

	// Equilibrium Loop
	for (int t = 0; t < n_equil; t++)
	  Metropolis(solid);

	// Measure Loop      
	s_fmp = 0. ;
	ss_fmp = 0. ;

	for (int t = 0; t < n_steps; t++)
	  {
	    // Evolve
	    Metropolis(solid);
	    // Measure Energy and FMP
	    solid->measure();
	    t_fmp = solid->get_fmp(initial_state);
	    s_fmp += t_fmp;

	    // Measure each 'stepAvg' steps
	    if( t % stepAvg == 0 )
	      {
		s_fmp += s_fmp / stepAvg;	 
		fmp += s_fmp;
		ss_fmp += fmp*fmp;	  
		s_fmp = 0.;
	      }
	  }

	// Calculate averages and error

	fmp = fmp / n_measures;
	err_fmp = (ss_fmp/n_measures - fmp*fmp) / n_measures;
	err_fmp = sqrt( abs( err_fmp ) );
      
	// Write to file
	out_file
	  << temperature <<tab
	  << fmp <<tab
	  << err_fmp <<tab
	  <<endl;
    
	temperature += incr_temperature;
      }
    out_file.close();  
  }
  
  //////////////////////////////////////////////////////////////////////
  //////////////////////////////////////////////////////////////////////
  
  // Plots
  //sys_cmd = system(plot_pv);
  //  sys_cmd = system(plot_gas);
  //sys_cmd = system(plot_solid);
   sys_cmd = system(plot_fmp);

  return 0;
}
