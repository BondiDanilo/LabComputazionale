#include "include/constants.h"
#include "MonteCarlo.h"
using namespace std;

int main()
{
  return 0;
}

