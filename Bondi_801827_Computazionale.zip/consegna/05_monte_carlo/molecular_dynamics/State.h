//////////////////////////////////////////////////////////////////////
//                                                                  //
// This class contains the definitions of the states that can be    //
// used in the METROPOLIS algorithm.                                //
//                                                                  //
//////////////////////////////////////////////////////////////////////
//                                                                  //
// This class can be edited by the user, following these rules      //
//      - Member NAMES must remain the same, in order to avoid      //
//        conflict with functions in file "MonteCarlo.h"            //
//      - Only public members are called in "MonteCarlo.h",         //
//        so it is important not to change their structure          //
//        (e.g. arguments, ...). What each function actually do     //
//        is completely up to the user and it should not give       //
//        problems.                                                 //
//                                                                  //
//////////////////////////////////////////////////////////////////////

// Manage parameters vector

#ifndef STATE
#define STATE
#include <fstream>
#include <vector>
#include <random>
#include "include/constants.h"
#include "include/functions.h"
#include "debug.h"

// This defines the type of the variables of the system.
// It can be edited by the user to match the system requirements.
typedef double type;

using namespace std;
// This will depend on the system in consideration


class State
{
 //////////////////////////////////////////////////
 // User can ONLY edit:                          //
 //   - the type of '_variables'                 //
 //   - the definition of 'get_probability()'    //
 //   - the 'randomize' function                 //
 // to match the desired sistem                  //
 //////////////////////////////////////////////////
  
 private:
  // GENERAL: DO NOT EDIT
  type ** _variables;
  int _size1, _size2;
  vector <double>* _parameters;

  // Specific
  double _tot_energy, _kin_energy, _pot_energy;
  double _momentum, _pressure, _density, _fmp;
 //////////////////////////////////////////////////
 //           DO NOT EDIT THESE                  //
 //////////////////////////////////////////////////
 public:
  State();
  State(int,int); //
  State(type** variables);
  State(string);
  ~State();

  State operator = (State);
  void copy(State*); //

  ////////// GENERAL: DO NOT CHANGE NAMES //////////
  // Initialization
  void initialize(); //
  void initialize(std::vector<double>*); //
  void set_size(int,int);//
  int get_size();
  int get_size(int);
  type** get_variables();
  vector <double>* get_parameters();
  void set_parameters();

  // Probability
  double get_probability(State*, std::vector <double>*); //
  void randomize(); //
  void randomize_single_element(); //

  //////////////////// Specific ////////////////////
  void set_coordinates();
  void set_velocities();
  void shift_coordinates();
  void shift_velocities();
  void apply_boundary_conditions();
  void measure();
  void compute_properties();
    
  // Measures
  double get_fmp(State*);
  double get_pressure();
  double get_energy();
  double get_momentum();
  double get_energy(std::vector<double>*);
  double get_kinetic_energy();
  double get_potential_energy();
  void scale_coordinates(double);
  void scale_velocities(double);
  void fix_zero_pressure();
  void print_lattice();
  void print_coordinates();
  void print_velocities();
  void save(string);
  // unused until now
  State operator + (State);
};

State::~State()
{
}

State::State(string filename)
{
  ifstream file;
  _size1 = nAtom;
  _size2 = 7;
  file.open(filename);
  for (int n = 0; n<nAtom; n++)
  {
    _variables[n][0] = 0.;
    file >>_variables[n][1];
    file >>_variables[n][2];
    file >>_variables[n][3];
    file >>_variables[n][4];
    file >>_variables[n][5];
    file >>_variables[n][6];
  }
  file.close();
}

State::State()
{
  _size1 = 1;
  _size2 = 1;
  _variables = new type*[_size1];
  for (int i = 0; i<_size1; i++)
    _variables[i] = new type[_size2];
  for (int n=0; n<nAtom ;n++)
    _variables[n][0] = 0.;
  this -> initialize();
}

// MarkovChain calls this function
State::State(int size1, int size2)
{
  _size1 = size1;
  _size2 = size2;
  _variables = new type*[_size1];
  for (int i = 0; i<_size1; i++)
    _variables[i] = new type[_size2];
  for (int n=0; n<nAtom ;n++)
      _variables[n][0] = 0.;
  this->initialize();
}

State State::operator=(State a_state)
{
  this->_variables = a_state._variables;
  this->_size1 = a_state._size1;
  this->_size2 = a_state._size2;
  return *this;
}

void State::copy(State* old_state)
{
  _size1 = old_state->get_size(1);
  _size2 = old_state->get_size(2);
  _parameters = old_state->_parameters;
  for(int i = 0 ; i < _size1 ; i++)
    for(int j = 0 ; j < _size2 ; j++)
      _variables[i][j] = old_state->_variables[i][j];
}

void State::initialize()
{
  set_coordinates();
  set_velocities();
  compute_properties();
  /*
  _tot_energy = 0.;
  _kin_energy = 0.;
  _pot_energy = 0.;
  _momentum = 0.;
  _pressure = 0.;
  _density = density;
  */
  return;
}

void State::initialize(std::vector <double>* parameters)
{
  return;
}

void State::set_coordinates()
{
  double c[nDim+1];
  double h = 0.5;        // h = 0.75 fcc ; h = 0.5 else
  int n = -1;
  
  if (fcc == 1)
    h = 0.75;
  
  for (int nZ = 1 ; nZ <= initUcell[3] ; nZ++)
  {
    c[3] = (nZ-h)*gap[3] - regionH[3];
    for (int nY = 1 ; nY <= initUcell[2] ; nY++)
    {
      c[2] = (nY-h)*gap[2] - regionH[2];
      for (int nX = 1 ; nX <= initUcell[1] ; nX++)
      {
	c[1] = (nX-h)*gap[1] - regionH[1];
	if (fcc == 1)
	{
	  for (int j=1;j<=4;j++)
	  {
	    n = n+1;
	    _variables[n][0] = 0.;
	    for (int k =1 ;k <= nDim; k++)
	    {
	      if(j==k || j==4)	    
		_variables[n][k] = c[k];
	      else	    
		_variables[n][k] = c[k] + 0.5*gap[k];	    
	    }
	  }
	}
	else
	{
	  n = n+1;
	  for (int k = 1 ; k <= nDim ; k++)
	    _variables[n][k] = c[k];
	}
      }
    }
  }
  return;
}

void State::set_velocities()
{
  double velSum[nDim+1], ang, teta;

  for(int k=1; k<=nDim; k++)
    velSum[k] = 0.;
  
  for (int n=0; n<nAtom ;n++)
  {
    ang = rand_angle();
    teta = 0.5*rand_angle();
    _variables[n][4] = vMag*cos(ang)*cos(teta);
    _variables[n][5] = vMag*sin(ang)*cos(teta);
    _variables[n][6] = vMag*sin(teta);
    for(int k=1; k<=nDim; k++) 
      velSum[k] += _variables[n][k+3];
  }
  for(int k=1; k<=nDim; k++)
    velSum[k] /= nAtom;
  for (int n=0; n<nAtom ;n++)
    for(int k=1; k<=nDim; k++)
      _variables[n][k+3] -= velSum[k];

  return;
}
// Method 1: Randomize single element
void State::randomize_single_element()
{
  return;
}

//Method 2: Randomize whole state
void State::randomize()
{
  shift_coordinates();
  apply_boundary_conditions();
  shift_velocities();
  compute_properties();
  return;
}

void State::shift_coordinates()
{
  // Moves particle within a radius less tan gap/2
  // This to avoid the unlikely event than a particle
  // moves +gap/2 and the neighbour -gap/2 and they end
  // up in the same spot, giving a singularity for energy
  double delta = 0.001;
  // delta = 0.25
  for (int n=0; n<nAtom ;n++)
    for(int k=1; k<=nDim; k++)    
     _variables[n][k] += gap[k]*rand_number(-delta,delta);   
  return;
}

void State::apply_boundary_conditions()
{
  double r;
  for (int n=0; n<nAtom ;n++)
  {
    for(int k=1; k<=nDim; k++)
    {
      r = _variables[n][k];
      if (r >= regionH[k])
	r = r - region[k];
      else if(r < -regionH[k])
	r = r + region[k];
    }
   }
  return;
}

void State::shift_velocities()
{
  // This way the temperature should always be constant because at
  // each step we are sure that velocities have the correct
  // magnitude 
  double vx,vy,vz,dx,dy,dz,vxy;
  double ang,teta,d_ang, d_teta;
  
  for (int n=0; n<nAtom ;n++)
  {
    d_ang = rand_angle();
    d_teta = 0.5*rand_angle();
    _variables[n][4] = vMag * cos(d_ang) * cos(d_teta);
    _variables[n][5] = vMag * sin(d_ang) * cos(d_teta);
    _variables[n][6] = vMag * sin(d_teta);
  }
  return;
}

//////////////////////////////////////////////////////////////////////
//                       THERMODYNAMICS                             //
//////////////////////////////////////////////////////////////////////
void State::compute_properties()
{
  double k_energy = 0., u_energy = 0., f_virial = 0.;
  double vv, dr, rr, fcval;
  double vx, vy, vz;
  double px = 0. , py = 0. , pz = 0. ;
  double rri3;
  
  for (int n=0; n<nAtom ;n++)
  {
    // Accumulate velocities (for Kinetic Energy and Momentum)
    vx = _variables[n][4];
    vy = _variables[n][5];
    vz = _variables[n][6];    
    vv = vx*vx + vy*vy + vz*vz ;
 
    k_energy += vv;
    px += vx;
    py += vy;
    pz += vz;
    
    // Evaluate distancs between pairs
    for (int m = 0; m < n ; m++)
    {
      rr = 0.;
      // Calculate square distance with periodic conditions
      for(int k=1; k<=nDim; k++)
      {
	dr =_variables[n][k] - _variables[m][k] ;
	if (abs(dr) > regionH[k])
	  dr = dr - SignR(region[k],dr);
	rr += dr*dr;
      }
      if (rr<rrCut)
      {
	rri3 = 1./pow(rr,3);
	// Potential Energy
	u_energy += 4.0*rri3*(rri3-1) - uCut;
	// Virial sum
	fcval = 48.0*rri3*(rri3-0.5) / rr;
	f_virial += fcval*rr;
      }
    }
  }
  
  _kin_energy = 0.5 * k_energy / nAtom;
  _pot_energy = u_energy / nAtom;

  // Total Energy
  _tot_energy = _kin_energy + _pot_energy ;

  // Total Momentum
  _momentum = sqrt( px*px + py*py + pz*pz );
    if (_momentum < 1e-9)
    _momentum = 0.;

  // Pressure
  _pressure  = density * (k_energy + f_virial) / (nAtom * nDim) ;

  return;
}

void State::measure()
{
  compute_properties();
  return;
}

double State::get_pressure()
{
  return _pressure;
}

double State::get_kinetic_energy()
{
  return _kin_energy;
}

double State::get_potential_energy()
{
  //cout <<"Potential Energy: " <<_pot_energy <<endl;
  return _pot_energy;
}

double State::get_energy()
{
  return _tot_energy;
}

double State::get_momentum()
{
  return _momentum;
}

double State::get_energy(std::vector <double> * parameters)
{
  return 1.;
}

double State::get_fmp(State* initial_state)
{
  double fmp = 0.;
  double x,y,z,x0,y0,z0;
  for (int n = 0 ; n<nAtom ;n++)
  {
    x0 = initial_state->_variables[n][1];
    y0 = initial_state->_variables[n][2];
    z0 = initial_state->_variables[n][3];
    x  = _variables[n][1];
    y  = _variables[n][2];
    z  = _variables[n][3];
    fmp += (x-x0)*(x-x0) + (y-y0)*(y-y0) + (z-z0)*(z-z0);
  }
  fmp = fmp / nAtom;
  fmp = sqrt( abs( fmp ) );
  _fmp = fmp;
  return _fmp;
}

// Probability to transition from current state to a new state
double State::get_probability(State * new_state, std::vector <double> * parameters)
{
  double beta = 1./temperature;
  double p, deltaE;
  //  deltaE = new_state->get_energy() - this->get_energy() ;
  deltaE = new_state->get_potential_energy() - this->get_potential_energy() ;
  p = exp(-beta * deltaE);
  //cout <<"Probability: " <<p <<endl;
  return p;
}

void State::set_size(int size1,int size2)
{
  _size1 = size1;
  _size2 = size2;
  _variables = new type*[_size1];
  for (int i = 0; i<_size1; i++)
    _variables[i] = new type[_size2];
  return;
}

int State::get_size()
{
  return _size1*_size2;
}

int State::get_size(int index)
{
  int size;
  switch(index)
  {
  case 0:
    size = _size1*_size2;
    break;
  case 1:
    size = _size1;
    break;
  case 2:
    size = _size2;
    break;
  }
  return size;
}

type ** State::get_variables()
{
  return this->_variables;
}

void State::scale_coordinates(double scale)
{
  for (int n=0; n<nAtom ; n++)
  {
    _variables[n][1] = scale * _variables[n][1];
    _variables[n][2] = scale * _variables[n][2];
    _variables[n][3] = scale * _variables[n][3];
  }
  return;
}

void State::scale_velocities(double scale)
{
  for (int n=0; n<nAtom ; n++)
  {
    _variables[n][4] = scale * _variables[n][4];
    _variables[n][5] = scale * _variables[n][5];
    _variables[n][6] = scale * _variables[n][6];
  }
  return;
}
void State::fix_zero_pressure()
{
  //  cout <<"Fix pressure called." <<endl;
  bool ok = 0;
  while(ok == 0)
  { 
    if(_pressure > 1e-4)
    { 
      this->scale_coordinates(1.1);
      this->compute_properties();
    }
    else
      ok = 1;
  }
  return;
}

//////////////////////////////////////////////////////////////////////
//                           PRINT                                  //
//////////////////////////////////////////////////////////////////////
void State::print_lattice()
{
  for (int i=0 ; i<_size1 ; i++)
  {
    for (int j=0 ; j<_size2 ; j++)
    {
      cout <<_variables[i][j] <<"\t";
    }
    cout <<endl;
  }
  return;
}

void State::print_coordinates()
{
  cout <<"Coordinates:" <<endl;
  for (int n=0; n<nAtom ;n++)
  {
    cout
      <<_variables[n][1] <<tab
      <<_variables[n][2] <<tab
      <<_variables[n][3] <<tab
      <<endl;
  }
  return;
}

void State::print_velocities()
{
  cout <<"Velocities:" <<endl;
  for (int n=0; n<nAtom ;n++)
  {
    cout
      <<_variables[n][4] <<tab
      <<_variables[n][5] <<tab
      <<_variables[n][6] <<tab
      <<endl;
  }
  return;
}

void State::save(string filename)
{
  ofstream file;
  file.open(filename);
  
  for (int n = 0; n<nAtom; n++)
  {
    file
      <<_variables[n][1] <<tab
      <<_variables[n][2] <<tab
      <<_variables[n][3] <<tab
      <<_variables[n][4] <<tab
      <<_variables[n][5] <<tab
      <<_variables[n][6] <<tab
      <<endl;
  }
  file.close();
  return;
}

#endif

