
#include <iostream>
#include <fstream>
#include <cmath>
#include "MonteCarlo.h"
#include "include/constants.h"
#include "include/initialization.h"

#include "debug.h"
using namespace std;

int main(int argc, char**argv)
{
  bool equilibrium = 0;
  srand(time(NULL));
  int sys_cmd;
  // Plot
  const char * plot_cmd = "gnuplot -p gas.gnu";
  const char * plot_pv = "gnuplot -p pv.gnu";

  const string file  = "gas.data";
  const string file1 = "gas1.data";
  const string file2 = "gas2.data";
  const string file3 = "gas3.data";
  const string file4 = "gas4.data";
  string initial_configuration = "init_state00000.data";
  int id = 1;

  ofstream out_file;
  ifstream in_file;

  // Loop constants
  int init_cell = 3;
  int n_steps  = 7000;
  int n_equil  = 7000;
  int n_measures;

  int n_series = 5;
  int n_points = 30;

  // Loop variables
  double min_temperature  = 1.;
  double max_temperature  = 3. ;
  double incr_temperature = (max_temperature-min_temperature) / n_series;
  
  double min_density  = .01;
  double max_density  = .1 ;
  double incr_density = (max_density-min_density) / n_points;

  // Measures
  double t_pressure, s_pressure, ss_pressure; // Accumulation
  double pressure, err_pressure;

  temperature = 2.0;
  density = .5;

  // Initialize parameters
  InitializeSystem(init_cell, 1.0, 1.0);
  
  // System
  State * gas = new State(nAtom,7);

  //////////////////////////////////////////////////
  //          1. Real Gas - PV curves             //
  //////////////////////////////////////////////////

  n_steps = 5000;
  n_equil = 10000;
  n_measures = n_steps / stepAvg;

  min_temperature = 0.5;
  max_temperature = 1.8;
  incr_temperature = (max_temperature - min_temperature)/n_series;

  min_density = 0.2;
  max_density = 0.5;
  incr_density = (max_density - min_density)/n_points;
  
  temperature = min_temperature;
  density = min_density;

  //////////////////////////////////////////////////////////////////////  
  //////////////////////////////////////////////////////////////////////
  temperature = 2.0;
  out_file.open(file2);
  //////////////////////////////////////////////////////////////////////
  //////////////////////////////////////////////////////////////////////
  
  //  while (temperature <= max_temperature)
  {
    cout <<"Temperature " <<temperature <<"/" <<max_temperature <<endl;
    cout <<"Progress: " <<endl; 
    out_file <<"# Temperature | Volume/N | Pressure | errPressure " <<endl;
    while (density <= max_density) // Reset density to 'min_density' at the end
    {
      cout <<100*density/max_density <<"%" <<endl;
      // Set Parameters
      InitializeSystem(init_cell,temperature,density);
      gas->initialize();
     
      // Equilibrium Loop
      for (int t = 0; t < n_equil; t++)
	Metropolis(gas);

      // Measure Loop      
      s_pressure = 0. ;
      ss_pressure = 0. ;

      for (int t = 0; t < n_steps; t++)
	{
	  // Evolve
	  Metropolis(gas);
	  // Measure Pressure
	  //	gas->measure();
	  t_pressure = gas->get_pressure();
	  s_pressure += t_pressure;

	  // Measure each 'stepAvg' steps
	  if( t % stepAvg == 0 )
	    {
	      s_pressure = s_pressure / stepAvg;
	      pressure += s_pressure;
	      ss_pressure += pressure*pressure;
	      s_pressure = 0.;
	    }
	}

      // Calculate averages and error
      pressure = pressure / n_measures;
      err_pressure = (ss_pressure/n_measures - pressure*pressure) / n_measures;
      err_pressure = sqrt( abs( err_pressure ) );
      
      // Write to file
      out_file
	<< temperature <<tab
	<< 1./density <<tab
	<< pressure <<tab
	<< err_pressure <<tab
	<<endl;

      density += incr_density;
    }
    out_file <<endl <<endl;
    
    
    temperature += incr_temperature;
    density = min_density;
    cout <<endl <<endl;
  }
  out_file.close();
  
  //////////////////////////////////////////////////////////////////////
  //////////////////////////////////////////////////////////////////////
  
  // Plots
  sys_cmd = system(plot_pv);
  delete gas;
  return 0;
}
