#include "constants.h"
//#include "../initial_state/init-generation.h"
#include <cmath>
#include <iostream>
#include "../debug.h"

#ifndef INITIALIZATION
#define INITIALIZATION

void GetNameList(int nAtom_per_side, double temperature_, double density_)
{
  initUcell[1] = nAtom_per_side;
  initUcell[2] = nAtom_per_side;
  initUcell[3] = nAtom_per_side;
  volume = 0.;
  density = density_;
  temperature = temperature_;
  stepLimit = 5000;
  stepAvg = 100;
  return;
}

void SetVolume()
{
  double vCut = 4./3.*pi*pow(rCut,3);

  if(volume != 0.0 && density == 0.0)
    density = nAtom/volume;
  else if (density != 0.0 && volume == 0.0)
    volume = nAtom/density;
  else if (density == 0.0 && volume == 0.0)
  {
    cout << "DENSITY and VOLUME are both ZERO." <<endl;
    return;
  }
  else if (density /= nAtom/volume)
  {
    cout <<"ERROR: VOLUME and DENSITY are not consistent with themselves." <<endl;
    return;
  }

  return;
}

void SetParameters()
{
  // Set distance cutoff and potential energy shift
  rCut = 2;
  rrCut = rCut*rCut;

  double rri3;
  rri3 = 1./(rrCut*rrCut*rrCut); // Contains 1/(rCut^2)^3
  uCut = 4.0 * rri3*(rri3-1);
  //  uCut = LJPotential(rCut**2);

  // Set the total number of atoms by multiplying the number
  // of atoms in each direction ( initUcell(k) )
  nAtom = initUcell[1]*initUcell[2]*initUcell[3];
  if (fcc ==1 )
    nAtom *= 4;
  if (nAtom == 0)
  {
    cout << "Warning. There are no atoms in the system" <<endl;
    return;
  }
  
  // Variables needed for measuring in AccumProp
  nMeasure = stepLimit/stepAvg;     // (Total timesteps) / (measuring n. steps interval)
  idMeas = 0;
  // Variables needed to calculate time average values
  stepAvgTime = stepAvg;                 // It can be set to a different value by choice
  nTimesteps = stepLimit/stepAvgTime;

  // Measured quantities
  avgPressure = 0.;
  varPressure = 0.;
  avgEnergy   = 0.;
  varEnergy   = 0.;
  avgTemp     = 0.;
  varTemp     = 0.;
  avgFMP      = 0.;
  varFMP      = 0.;

  // Setting the volume/density variable
  SetVolume();
  // Setting the cube sides
  for(int k =1; k<= nDim; k++)
  {   
    region[k] = initUcell[k] * pow( 4./density , 1./3. );
    regionH[k] = 0.5 * region[k];
    gap[k] = regionH[k]/initUcell[k];
  } 
  
  // Average velocity magnitude from temperature
  vMag = sqrt( nDim * (1.0 - 1.0/nAtom) * temperature );

  return;
}

void InitializeSystem(int nAtom_per_side, double temperature_, double density_)
{
  GetNameList( nAtom_per_side, temperature_, density_);
  SetParameters();
  return;
}
void InitializeSystem()
{
  GetNameList( 2, 1.0, 1.0 );
  SetParameters();
  return;
}

#endif
