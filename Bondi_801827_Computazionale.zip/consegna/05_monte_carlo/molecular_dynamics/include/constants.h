#include <string>
#include <vector>
#ifndef CONSTANTS
#define CONSTANTS
using namespace std;
const string tab = "\t";
const double  pi = 3.14159265359;
const  int nDim = 3;

//// Variables for multiple runs of the main file
int  firstRun, lastRun, runLimit, nSeries, runPerSeries;
int  rId, sId, nId;

//// rId = run id within the series
//// sid = series id
//// nId = global run id
  
//double ** r, rv, ra; //// Coordinates, velocities, accellerations

//// Initial positions and velocities (for FMP calculation)
//double **r0, rv0;
//// rv0 is not actually used in the code
  
double  region[nDim+1], regionH[nDim+1], gap[nDim+1];
//// region(k) = lenght of the simulating region (box) in direction k
//// regionH = cotains half this values, because these are frequently used

//// Global constants
int  nAtom, runId, moreCycles;
int  randSeed = 17;

double  rCut, rrCut, uCut, vMag;
//// rCut is the distance cutoff in calculating the forces
//// vMag is the magnitude of the average velocity, depends on temperature
double  pressure, temperature;
double  volume = 0.0, density = 0.0;
double  deltaT = 0.005;
  
int initUcell[nDim+1];
//// initUcell(k) = Number of lattice sites in the direction k
bool  fcc = 0;
//// fcc = flag to initialize a fcc type lattice

//// Step variables
int  stepCount, stepEquil;
//// stepCount = the current step number in integration process
//// stepEquil = n. steps to reach thermal equilibrium
int  stepAvg   = 200;
//// stepAvg   = avg n. of steps to take measurements
int  stepLimit = 7000;
//// stepLimit = maximum number of steps in evolution
int  stepAdjT  = 50;
//// stepAdjT = n. of steps to rescale velocities to reset temperature
  
//// Thermodynamic properties (accumulation)
double  sKinEnergy, sPressure, sTotEnergy, sFMP;
//// sX = accumulated sum to compute MEANS
double  ssKinEnergy, ssPressure, ssTotEnergy, ssFMP;
//// ssX = accumulated sum of squares to compute STDEVS

//////////////////////////////////////////////////////////////////////
//                     MEASURING VARIABLES                          //
//////////////////////////////////////////////////////////////////////
vector <double>  mPressure, mmPressure, mTemperature;
//// mX are vectors containing the measure of X at the various measuring times
//// they are only used in computing the self correlation time
int  idMeas;
//// index to access the vectors mPressure, etc, for the single measurements
double  avgPressure, avgEnergy, avgTemp, avgFMP;
double  varPressure, varTemp, varEnergy, varFMP;
//// These will contain the final measured quantities and errors
int  nMeasure; //// Number of measures
  
//// Dynamic quantities
double  kinEnergy, potEnergy, totEnergy;
double  uSum, virSum, vSum, vvSum;
//// These are used in measuring the quantities every stepAvg timesteps
//// uSum = Accumulated sum of potential energy
//// vSum = Acc. sum of all the components of the total momentum (velocity, in MD Units)
//// vvSum = Acc. sum of all velocities (Total kinetic energy)
//// virSum = Acc. sum of the virial term (Fij*rij) (Pressure)
  
//////////////////////////////////////////////////////////////////////
//                     HISTOGRAM VARIABLES                          //
//////////////////////////////////////////////////////////////////////
//// Histograms
//vector<double> histVel(:), histR(:);

//// Velocity Histogram
//double     rangeVel = 4.;
//double     deltaHistVel; 
//int  sizeHistVel = 50;
  
//// Radial distribution Histogram
//double     rangeR   = 12.;
//      double     deltaHistR;
//int  sizeHistR = 70;
  
int  nTimesteps;
double  stepAvgTime;
//int  histCallCount = 0;
//// Counts the number of times Fill Histogram function is called

//double  hFunctionNow = 0.;
  
//////////////////////////////////////////////////////////////////////
//                            PLOTTING                              //
//////////////////////////////////////////////////////////////////////

string plotFile ;
string plotCommand = "gnuplot -p "  ;
string  outputData = "plot/output.data" ;
  
//////////////////////////////////////////////////////////////////////
//                 PRINTING SWITCH VARIABLES                        //
//////////////////////////////////////////////////////////////////////
int  debug      = 0;
int  printVel   = 0;
int  printR     = 0;
int  evoSumm    = 0;
int  printEMCons = 0;
int  printSumm  = 0;
//int  printH     = 0;  // unused
int  plotGraph  = 0;
int  corrTime   = 0;
int  genFile    = 0;
int  singleRun  = 0;
/*
  //////////////////////////////////////////////////////////////////////
  //                           NAMELIST                               //
  //////////////////////////////////////////////////////////////////////
  namelist /initialization/ &
  runId, &
  ////   THERMODYNAMIC VARIABLES
  initUcell, &
  density, &
  temperature, &
  volume,&
  ////   EVOLUTION VARIABLES
  deltaT, &
  randSeed, &
  stepAvg, &
  stepEquil, &
  stepLimit, &
  stepAdjT, &
  ////   HISTOGRAM PARAMETERS      
  rangeVel,&
  sizeHistVel,&
  stepVel,&
  rangeR,&
  sizeHistR,&
  stepR,&
  ////   LATTICE PARAMETERS
  fcc,&
  ////   SWITCHES
  printVel,&
  printR,&
  evoSumm,&
  printSumm,&
  printH,&
  corrTime,&
  genFile,&
  singleRun,&
  ////   PLOT INSTRUCTIONS
  plotFile,&
  outputData
*/

#endif
