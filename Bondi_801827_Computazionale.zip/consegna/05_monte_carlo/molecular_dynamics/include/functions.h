#include "constants.h"
#include <random>

#ifndef FUNCTIONS
#define FUNCTIONS

double rand_number(double min, double max)
{
  double r = (double) rand()/RAND_MAX;
  return min + r*(max-min);
}

double rand_number()
{
  return (double) rand()/RAND_MAX;
}

double rand_angle()
{
  return 2*pi* (double) rand()/RAND_MAX;
}

double LJPotential(double rr)
{
  // Lennard Jones potential in MD units written as
  // a function of r^2
  double rri3 , u = 0.;
  if (rr <= rrCut)
  {
    rri3 = 1./(rr*rr*rr); // Contains 1/(r^2)^3
    u = 4.0 * rri3*(rri3-1) - uCut;
  }
  return u;
}

double LJForce(double rr)
{
  // Lennard Jones force in MD units written as
  //   a function of r^2
  double rri3, res = 0.;
  if (rr<= rrCut)
  {
    rri3 = 1/(rr*rr*rr);
    res = 48.0 * rri3 * (rri3-0.5) / rr;
  }
  return res;
}

double SignR(double x,double y)
{
  double res;
  if (y >= 0)
    res = x;
  else
    res = -x;
  return res;
}

#endif
