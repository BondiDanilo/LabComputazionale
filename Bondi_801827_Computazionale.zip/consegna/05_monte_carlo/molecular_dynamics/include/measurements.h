!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!
!! The following functions cover the measurements of the basic      !!
!! thermodynamic properties of the system.                          !!
!! vSum is the total momentum of the system. This should remain     !!
!! exactly zero. Simple check of the correctness of the calculation !!
!!                                                                  !!  
!! 'Props' stands for "properties" and refers to the basic          !!
!! thermodynamic properties of the system: pressure, energy, ...    !!
!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!

subroutine EvalProps
  use CONSTS
  !! 'EvalProps' computes the velocity and velocity-squared sums
  !! and the instantaneous energy and pressure values. 
  real :: v,vv
  integer :: k,n
  vSum = 0.
  vvSum = 0.
  do n=1,nAtom
     vv = 0.
     do k=1,nDim
        v = rv(k,n) - 0.5 * ra(k,n) * deltaT  !! Leapfrog method for v
        vSum = vSum + v
        vv = vv + v**2
     end do
     vvSum = vvSum + vv
  end do
  kinEnergy = 0.5*vvSum/nAtom
  potEnergy = uSum / nAtom !! Check uSum
  totEnergy = kinEnergy + potEnergy
  pressure  = density * (vvSum + virSum) / (nAtom * nDim) 
  !! Pressure from the Virial Theorem  
end subroutine EvalProps

subroutine AccumProps (icode)
  use CONSTS
  !! 'AccumProps' collects the results of the measurements, and evaluates
  !! means and stdevs upon request.

  !!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!
  !! It is assumed that the arguments of the sqrt are non-negative; for !!
  !! quantities that fluctuates, rounding errors can sometimes lead to  !!
  !! very small but negative values. These should be set to zero        !!
  !!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!
  
  !! Depending on the argument 'icode' (0,1 or 2) 'AccumProps' will:

  integer :: icode
 
  if ( icode == 0 ) then
     !! argument '0' initialize the accumulated sums to 0
     sTotEnergy   = 0.
     ssTotEnergy  = 0.
     sKinEnergy   = 0.
     ssKinEnergy  = 0.
     sPressure    = 0.
     ssPressure   = 0.
     sFMP         = 0.
     ssFMP        = 0.

  else if ( icode == 1 ) then
     !! argument '1' accumulates the sums and square sums
     sTotEnergy   = sTotEnergy + totEnergy
     ssTotEnergy  = ssTotEnergy + totEnergy**2
     sKinEnergy   = sKinEnergy + kinEnergy
     ssKinEnergy  = ssKinEnergy + kinEnergy**2
     sPressure    = sPressure + pressure
     ssPressure   = ssPressure + pressure**2
     sFMP         = sFMP + FreeMeanPath()
     ssFMP        = ssFMP + FreeMeanPath()**2
     !! cosi sto accumulando valori sempre rispetto al tempo zero

  else if ( icode == 2 ) then
     !! argument '2' calculates means (sX) and stdevs (ssX)
     sTotEnergy   = sTotEnergy / stepAvg                            
     ssTotEnergy  = sqrt( abs( ssTotEnergy / stepAvg - sTotEnergy**2 ) )   
     sKinEnergy   = sKinEnergy  / stepAvg                           
     ssKinEnergy  = sqrt( abs( ssKinEnergy / stepAvg - sKinEnergy**2 ) )
     sPressure    = sPressure / stepAvg                             
     ssPressure   = sqrt( abs(ssPressure / stepAvg - sPressure**2 ) )
     sFMP         = sFMP      / stepAvg
     ssFMP        = sqrt( abs(ssFMP / stepAvg - sFMP**2 ) )
     !! stdevs are useless at this point. maybe we can take as error the minimum
     !! between <ssX>/nMeasure and varX

     !! Measured quantities
     avgPressure = avgPressure + sPressure
     avgEnergy   = avgEnergy   + sTotEnergy
     avgTemp     = avgTemp     + sKinEnergy
     avgFMP      = avgFMP      + sFMP
     !! Sum of the squares of the measures
     varPressure = varPressure + sPressure**2
     varEnergy   = varEnergy   + sTotEnergy**2
     varTemp     = varTemp     + sKinEnergy**2
     varFMP      = varFMP      + sFMP**2

  else if(icode==3) then
     idMeas = idMeas + 1
     mPressure(idMeas) = sPressure
     if(idMeas == nMeasure) then
        idMeas = 0
     end if
  else
     print *, 'ERROR: AccumProps expects only 0,1,2,3 as argument. ',&
          'Please provide a valid argument.'
     stop
  end if
  
end subroutine AccumProps

subroutine GetMeasures  
  avgPressure = avgPressure / nMeasure
  avgEnergy   = avgEnergy   / nMeasure
  avgTemp     = avgTemp     / nMeasure
  avgFMP      = avgFMP      / nMeasure
  
  !! Variance is corrected for the N-1 bias
  varPressure = varPressure/ nMeasure - avgPressure**2
  varEnergy   = varEnergy  / nMeasure - avgEnergy**2
  varTemp     = varTemp    / nMeasure - avgTemp**2

  varPressure = varPressure / (nMeasure-1)
  varEnergy   = varEnergy   / (nMeasure-1)
  varTemp     = varTemp     / (nMeasure-1)

  varPressure = sqrt(abs(varPressure))
  varEnergy   = sqrt(abs(varEnergy))
  varTemp     = sqrt(abs(varTemp))

  !! Temperature = 2/nDim * kinEnergy
  avgTemp = avgTemp * 2/nDim
  varTemp = varTemp * 2/nDim
  
end subroutine GetMeasures

function CorrelationFunction(x,tStep) result(res)
  real :: res
  real, intent(in), dimension(nMeasure) :: x
  real :: xAvg, xVar
  integer :: tStep, i
  if (tStep >= nMeasure) then
     print *, 'ERROR: Correlation Function must be evaluated within domain'
     print *, 'It was requested at time:'
     print *, tStep, '>=', nMeasure
  end if
  res = 0.
  xAvg = 0.
  xVar = 0.
  do i=1,nMeasure
     xAvg = xAvg + x(i)
  end do
  xAvg = xAvg / nMeasure
  do i=1,nMeasure-tStep
     res = res + ( x(i) - xAvg ) * ( x(i+tStep) - xAvg )
     !res = res + x(i) * x(i+tStep)
     xVar = xVar + (x(i) - xAvg)**2
  end do
!  res = res - xAvg*xAvg
  res = res / (nMeasure-tStep)
  res = res / xVar
end function CorrelationFunction

!!$subroutine OldCorrelationTime(x)
!!$  real, intent(in), dimension(nMeasure) :: x
!!$  real :: pTime = 0.
!!$  integer :: i,t
!!$  if(corrTime==1) then
!!$     do t=1,nMeasure-1
!!$        pTime = pTime + 2*CorrelationFunction(x,t)
!!$        
!!$     end do
!!$     pTime = pTime*0.5
!!$     pTime = abs(pTime)
!!$     i = pTime/deltaT+1
!!$     print *, 'Correlation Time: ', pTime
!!$     print *, 'then stepAvg should be taken greater than ', 2*i
!!$  end if
!!$end subroutine OldCorrelationTime

subroutine CorrelationTime(x)
  real , intent(in), dimension(nMeasure) :: x
  real :: pTime = 0., sx = 0., ssx = 0., gamma = 0.
  integer :: i,j,k
 
  if (corrTime == 1) then
     !! Calculate average value and quadratic sums
     do i = 1,nMeasure
        sx = sx + x(i)
        ssx = ssx + x(i)*x(i)
     end do
     sx = sx / nMeasure
     ssx = ssx / nMeasure

     !! Calcualte correlation function
     do i = 1,nMeasure
        do j = 1,nMeasure-i
           gamma = 0.
           do k = 1, nMeasure-j
              gamma = gamma + x(k)*x(k+j)
           end do
           gamma = gamma / (nMeasure-j)
        end do
        pTime = pTime + (gamma-sx*sx)/(ssx-sx*sx)
     end do          
     pTime = 0.5*(1+2/nMeasure*pTime)
 !    pTime = abs(pTime)
     i = pTime/deltaT+1
     print *, 'Correlation Time: ', pTime
     print *, 'then stepAvg should be taken greater than ', 2*i
  end if
end subroutine CorrelationTime

real function FreeMeanPath() result(res)
  integer :: n,k
  res = 0.
  do n=1,nAtom
     do k=1,nDim
        res = res + (r(k,n)-r0(k,n))**2
     end do
  end do
  res = sqrt(abs(res / nAtom))
end function FreeMeanPath
