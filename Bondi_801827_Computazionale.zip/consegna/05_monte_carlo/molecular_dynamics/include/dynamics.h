!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!
!! The thermodynamic properties measured by the function AccumProps !!
!! are Kinetic Energy, Total Energy and pressure                    !!
!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!
subroutine Evolution
  use CONSTS
  stepCount = 0
  moreCycles = 1
  do while (moreCycles==1)
     call SingleStep
     call WriteEnergyMomentum
     if(stepCount >= stepLimit) then
        moreCycles = 0
     end if     
  end do  
end subroutine Evolution

subroutine SingleStep
  use CONSTS
  
  stepCount = stepCount + 1
 ! timeNow = stepCount * deltaT

  call ComputeForces
  call LeapfrogStep
  call ApplyBoundaryCond
  call AdjustTemp
  call EvalProps
  call AccumProps(1)       !! Accumulates sums and sq. sums

  !! Histogram
  call EvalHistograms
  
  if ( mod(stepCount, stepAvg) == 0 ) then
     call AccumProps(2)    !! Calculates means and stdevs
     call AccumProps(3)
     call EvolutionSummary
     call AccumProps (0)   !! Reset to 0 the accumulated sums
  end if

end subroutine SingleStep

subroutine ComputeForces
  use CONSTS
  use FUNC

  real :: dr(nDim)
  real :: f, fcVal, rrCut, rr
  integer :: n1, n2, n3, k, n
  
  !! Initialize variables
  rrCut = rCut**2

  do n = 1,nAtom
     do k = 1,nDim   
        ra(k,n) = 0.0
     end do
  end do
  uSum = 0.0
  virSum = 0.0
  rr = 0.0
  
  !!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!
  do n1 = 1,nAtom-1
     do n2 = n1+1,nAtom
        !! For each pair of atoms 1 < n1 < n2 < nAtom        
        rr = 0.0
        do k = 1,nDim
           dr(k) = r(k,n1) - r(k,n2)    !! difference in direction k
           if ( abs(dr(k)) > regionH(k) ) then
              !! Given a point A, L being the size of the box.
              !! If a generic point B is further from A more than L/2,
              !! then by periodicity there will be another point B' on
              !! the other side, which is closer to A.
              !! We define dr as the MINIMUM distance between two points
              !! by periodicity
              !!
              !!      -L      -L/2  B'   A      L/2  B    L
              !!       |--------:---o----O-------:---o----|
              
              dr(k) = dr(k) - SignR ( region(k), dr(k) )
           end if
           rr = rr + dr(k)**2           !! (x1-x2)^2 + (y1-y2)^2 + (z1-z2)^2
        end do

        !! Checking if by chance two atoms end up in the same position
        !! because 1/rr would be dividing by 0
        if ( rr == 0.0 ) then
           print *, 'ERROR: two atoms turned out at the same position'
           print *, 'for (n1, n2) = ' ,n1, n2              
           stop
        end if

        if (rr < rrCut) then
           !! Hard cutoff at rCut. Skipping pairs that are too far apart                
           fcVal = LJForce(rr)     !! Modulus of the elemerntary force
           
           do k = 1,nDim
              f = fcVal * dr(k)           !! F = mod(F) * vers(F)
              ra(k,n1) = ra(k,n1) + f
              ra(k,n2) = ra(k,n2) - f
           end do
!           uSum = uSum + LJPotential(rr) + uCut
           uSum = uSum + LJPotential(rr) - uCut
           !! Here the potential is shifted by it value at rCut       
           !! in this way the potential naturally goes to zero at rCut,
           !! and after rCut is forced to be zero by the if condition   
           virSum = virSum + fcVal * rr
        end if
     end do
  end do
  !!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!
end subroutine ComputeForces

subroutine LeapfrogStep
  !!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!
  !! If I change the integration method, I should also change the !!
  !! accumulation method of velocities in EvalProps               !!
  !!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!
  use CONSTS
  use FUNC
  integer :: k,n
 
  do n = 1,nAtom
     do k = 1,nDim
        rv(k,n) = rv(k,n) + deltaT * ra(k,n)
        r(k,n)  = r(k,n)  + deltaT * rv(k,n)        
     end do     
  end do
  
end subroutine LeapfrogStep

subroutine ApplyBoundaryCond
  use CONSTS
  integer :: k,n
  do n = 1,nAtom
     do k = 1,nDim
        if ( r(k,n) >= regionH(k) ) then
           r(k,n) = r(k,n) - region(k)
        else if ( r(k,n) < - regionH(k) ) then
           r(k,n) = r(k,n) + region(k)
        end if
     end do
  end do

end subroutine ApplyBoundaryCond

subroutine AdjustTemp
  real :: vFac
  integer :: n,k
  vvSum = 0.
  if (mod(stepCount, stepAdjT)==0) then
     if (temperature > 0.) then
        !! Calculating scaling factor = sqrt ( nAtom*nDim*temperature/vvSum )
        do n=1,nAtom
           do k=1,nDim
              vvSum = vvSum + rv(k,n)**2
           end do
        end do
        vFac = vMag * sqrt(nAtom/vvSum)        !! vMag = sqrt(nDim*T)
     else
        vFac = 0.
     end if
     !! Scale individual velocities
     do n = 1,nAtom
        do k = 1,nDim
           rv(k,n) = rv(k,n)*vFac
        end do
     end do
  end if
end subroutine AdjustTemp

