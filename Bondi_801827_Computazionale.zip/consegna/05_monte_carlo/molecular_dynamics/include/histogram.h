!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!
!!                     HISTOGRAM FUNCTIONS                          !!
!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!

subroutine InitializeHistograms
  call InitHist(histVel,sizeHistVel,printR,deltaHistR,rangeR)
  call InitHist(histR,sizeHistR,printVel,deltaHistVel,rangeVel)
end subroutine InitializeHistograms

subroutine InitHist(hist,sizeHist,printHist,deltaHist,rangeHist)
  use CONSTS
  real, dimension (:) :: hist
  real :: deltaHist,rangeHist
  integer :: j,sizeHist,printHist
  if (printHist==1) then
     !! Velocity and radial distributions histograms cannot
     !! be evaluated in a multi-run loop (s.a. EnergyConservation)
     singleRun = 1
     deltaHist = rangeHist / sizeHist
     do j=1,sizeHist
        hist(j) = 0.
     end do
  end if
end subroutine InitHist

subroutine EvalHistograms
  !! This is evaluated inside the evolutions
  if( mod( stepCount,stepAvg )== 0 .AND. stepCount >= stepEquil ) then
     histCallCount = histCallCount + 1

     call VelocityHistogram
     call RadialHistogram
     
     if ( histCallCount == nTimesteps ) then
        call NormalizeHistograms
     end if
  end if
end subroutine EvalHistograms

subroutine NormalizeHistograms
  use CONSTS
  implicit none
  real :: norm

  !! Velocity
  if(printVel==1)then
     norm = nTimesteps*nAtom
     call NormError(norm)
     call ScaleHist(histVel,sizeHistVel,1/norm)
  end if

  !! Radial Distribution
  if (printR==1) then
     norm = nTimesteps*nAtom*(nAtom-1)/2
     call NormError(norm)
     call ScaleHist(histR,sizeHistR,1/norm)       
  end if
  
!  end if
end subroutine NormalizeHistograms

subroutine NormError(norm)
  real :: norm
  if (norm <= 0) then
     print *, 'ERROR: Attempting to normalize an histogram with a non-positive norm factor'
     stop
  end if
end subroutine NormError

!! Normalizza istogramma
subroutine ScaleHist(hist,sizeHist,scale)
  implicit none
  integer :: j,sizeHist
  real :: scale
  real, dimension (:) :: hist
  do j=1,sizeHist
     hist(j) = scale * hist(j)
  end do
end subroutine ScaleHist

!! Calcola interale di istogramma
!! unused
function IntegrateHist(hist,sizeHist,printHist) result(histSum)
  integer :: sizeHist,j,printHist
  real,dimension (:) :: hist
  real :: histSum
  histSum = 0.
  if (printHist==1) then
     do j=1,sizeHist
        histSum = histSum + hist(j)
     end do
  end if
end function  IntegrateHist

!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!
!! Velocity Histogram !!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!
!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!

subroutine VelocityHistogram
  use CONSTS
  implicit none 
  real :: deltaV, histSum, vv
  integer :: j,n

  if (printVel==1) then

     deltaV = rangeVel / sizeHistVel

     do n=1,nAtom
        vv = rv(1,n)**2 + rv(2,n)**2 + rv(3,n)**2   !! Calcualtes the velocity
        j = sqrt(vv)/deltaV + 1    !! Find the index corresponding to the velocity
        if ( j > sizeHistVel ) then
           j = sizeHistVel
        end if

        histVel(j) = histVel(j)+1  !! Increment by 1 the corresponding bin

     end do
  end if
end subroutine VelocityHistogram

!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!
!! Radial Histogram !!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!
!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!

subroutine RadialHistogram
  use CONSTS
  implicit none 
  real :: deltaR, histSum, rr
  integer :: j,ni,nj

!  integer :: nInteract
  if (printR == 1) then  
     !! Setup the bin size  (dr = range/nbins)
     deltaR = rangeR / sizeHistR

     !! Now we have to fill the bins with the relative positions of the pairs
     do ni=1,nAtom
        do nj = ni+1,nAtom
           !! Calculate the distance between the pair
           rr = ( r(1,ni)-r(1,nj) )**2 + ( r(2,ni)-r(2,nj) )**2 + ( r(3,ni) - r(3,nj) )**2   
           !! Find the index corresponding to the current value of rr
           j = sqrt(rr)/deltaR + 1
           !! If overflow, increment the last bin
           if ( j > sizeHistR ) then
              j = sizeHistR
           end if
           !! Increment by 1 the corresponding bin
           histR(j) = histR(j)+1
           !        nInteract = nInteract + 1
        end do
     end do
  end if
end subroutine RadialHistogram

!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!
!!                          H FUNCTION                              !!
!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!

!! Unused
subroutine EvalHFunction(unit)
  use CONSTS
  real :: deltaV
  integer :: j, unit
  if(printH==1) then
     deltaV = rangeVel / sizeHistVel
     hFunctionNow = 0.
     do j=1,sizeHistVel
        if ( histVel(j) > 0. ) then
           hFunctionNow = hFunctionNow + &
                histVel(j) * log( histVel(j) / ( (j-0.5)*deltaV )**2 )
           !! At denominator there is `vel(j) = deltaV*(j-0.5)`,
           !! elevated to the `nDim-1` power
        end if
     end do
     write (unit,'(F8.4,A1,F8.4)') timeNow, tab, hFunctionNow
  end if
end subroutine EvalHFunction

