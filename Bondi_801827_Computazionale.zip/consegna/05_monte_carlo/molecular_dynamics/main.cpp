#include "include/constants.h" 
#include "include/functions.h"

#include "include/io.h"     
#include "include/initialization.h"
#include "include/dynamics.h"          
#include "include/measurements.h"
#include "include/histogram.h"       
#include "initial_state/init-generation.h"

void ReadArgument()
{
  character (len=8) :: argv
  if ( argc == 0 )   
    genFile = 1; // Use the subroutine Generate input
  else if (iargc() < 2)
  {
    // Execute the single run specified by input
    genFile = 0;
    nSeries = 1;
    runPerSeries = 1;
    call getarg(1,argv);
    read(argv,*) firstRun;
  }
  else if ( argc<3 )
  {
    genFile = 0 ;
    nSeries = 1;
    call getarg(1,argv);
    read (argv,*) firstRun;
    call getarg(2,argv);
    read (argv,*) runPerSeries;
  }
}

int main(int argc, char ** argv)
{
  ReadArgument();
  GenerateInput();
    
  for (int sId = 0; sId < nSeries-1 ; sId++)
  {
    for (int rId = 1; rId < runPerSeries ; rId++)
    {
      nId = firstRun + (rId-1) + runPerSeries*sId;
      call InitSystem;
      call Evolution;
      call Output;
    }	  
    call SeparateRuns;
  }
  Plot();
  return 0;
}

// for (int i = 0; i < nSeries-1 ; i++)
