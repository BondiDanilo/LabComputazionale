#ifndef MARKOVCHAIN
#define MARKOVCHAIN

#include <vector>
#include <random>
#include "State.h"

using namespace std;
//////////////////////////////////////////////////////////////////////
// The Markov chain contains the temporal evolution of the system   //
// in the vector '_state', which contains the system. State _state  //
// can contain whatever as a '_variables' member: numbers, vectors, //
// matrices, depending on how the user represents the system.       //
//                                                                  //
// EXAMPLE:                                                         //
// -  Ising model can be represented with a matrix at each time, so //
//    '_variables' will be an NxN matrix                            //
// -  A gas of N particles will be represented with N vectors       //
//    containing the potition and velocities at each time, i.e      //
//    a Nx6 matrix.                                                 //
//////////////////////////////////////////////////////////////////////
typedef vector<double> vdouble;
typedef vector<State>  vstate;
class MarkovChain
{
public:
  MarkovChain();
  MarkovChain(int);
  MarkovChain(int,int,int);
  MarkovChain(int,int, int, vdouble*);
  MarkovChain(int,vstate);

  int      get_size(int); //
  int      get_size();
  State*   get_state(int); //
  int      get_last_index();
  vdouble* get_parameters(); //
  
  void push_back(State*);
  void randomize();
  
  void initialize(int,int);
  void set_parameters(vdouble*); //
  void set_size(int);

  void print_sizes();

private:
  int _size, _state_size1, _state_size2;
  vdouble _parameters;
  vstate _states;
};

MarkovChain::MarkovChain()
{
  _size = 0;
  _state_size1 = 1;
  _state_size2 = 1;
}

MarkovChain::MarkovChain(int t_size,int state_size1,int state_size2)
{
  State t_state(state_size1,state_size2);
  
  _size = t_size;
  _state_size1 = state_size1;
  _state_size2 = state_size2;

  for(int t=0;t<_size;t++)
  {
    t_state.initialize();
    _states.push_back(t_state);
  }
}

MarkovChain::MarkovChain(int t_size,int state_size1, int state_size2, vdouble* parameters)
{
  State t_state(state_size1,state_size2);
  
  _size = t_size;
  _state_size1 = state_size1;
  _state_size2 = state_size2;
  _parameters = *parameters;

  for(int t=0;t<_size;t++)
  {
    t_state.initialize(parameters);
    _states.push_back(t_state);
  }
}

MarkovChain::MarkovChain(int size)
{
  _size = size;
  _state_size1 = 1;
  _state_size2 = 1;
}

MarkovChain::MarkovChain(int size,vstate states)
{
  _size = size;
  _states = states;
  _state_size1 = states[0].get_size(1);
  _state_size2 = states[0].get_size(2);
}

// Randomizes all the chain
void MarkovChain::randomize()
{
  for (int t = 0; t < _size ; t++)
    this->_states[t].randomize();
  return;
}

void MarkovChain::initialize(int state_size1, int state_size2)
{
  _states.resize(_size);
  for (int t = 0; t < _size ; t++)
  {   
    _states[t].set_size(state_size1,state_size2);
    _states[t].initialize();
  }
  return;
}

State* MarkovChain::get_state(int index)
{
  State* state_ptr; 
  state_ptr = &_states[index] ;
  return state_ptr;
}

int MarkovChain::get_last_index()
{
  return _states.size(); 
}

void MarkovChain::set_parameters(vdouble *parameters)
{
  _parameters = *parameters;
  return;
}

vdouble * MarkovChain::get_parameters()
{
  vdouble * param_ptr;
  param_ptr = &_parameters;
  return param_ptr;
}
void MarkovChain::set_size(int size)
{
  _size = size;
  return;
}
int MarkovChain::get_size()
{
  return _size;
}
int MarkovChain::get_size(int index)
{
  int size;
  switch(index)
  {
  case 0:
    size = _size;
    break;
  case 1:
    size = _state_size1;
    break;
  case 2:
    size = _state_size2;
    break;
  }
  return size;
}

void MarkovChain::print_sizes()
{
  cout
    <<" _size: " <<_size
    <<" state_size1: " << _state_size1
    <<" state_size2: " << _state_size2
    <<endl;
  return;
}

#endif
