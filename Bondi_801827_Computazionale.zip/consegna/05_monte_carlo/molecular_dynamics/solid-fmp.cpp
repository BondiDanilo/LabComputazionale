#include <iostream>
#include <fstream>
#include <cmath>
#include "MonteCarlo.h"
#include "include/constants.h"
#include "include/initialization.h"

#include "debug.h"
using namespace std;

int main()
{
  srand(time(NULL));
  int sys_cmd;
  // Plot
  const char * plot_cmd = "gnuplot -p solid-fmp.gnu";
  const string file = "solid-fmp.data";

  ofstream out_file;

  // Loop constants
  int init_cell = 5;
  int n_steps  = 7000;
  int n_equil  = 7000;
  int n_measures;

  int n_series = 5;
  int n_points = 10;

  // Loop variables
  double min_temperature  = 1.;
  double max_temperature  = 3. ;
  double incr_temperature = (max_temperature-min_temperature) / n_series;
  
  // Measures
  double t_fmp, s_fmp, ss_fmp;
  double fmp, err_fmp;

  temperature = 1.0;
  density = 0.5;
  
  //fcc = 1; // Set lattice to a FCC type 
  // Initialize parameters
  InitializeSystem(init_cell, 1.0, 1.0);
  
  // System
  State * solid = new State(nAtom,7);
  State * initial_state = new State(nAtom,7); 

  //////////////////////////////////////////////////
  //         3. Solid - Phase Transition          //
  //////////////////////////////////////////////////
  out_file.open(file);

  n_steps = 100000;
  n_equil = 100000;
  n_measures = n_steps / stepAvg;
  n_points = 10;
  
  min_temperature = 0.1;
  max_temperature = 2.5;
  incr_temperature = (max_temperature - min_temperature)/n_points;
  
  temperature = min_temperature;
  density = .5;
  
  out_file <<"# Temperature | FMP | errFMP " <<endl;  
  while (temperature < max_temperature)
  {
    cout << 100*temperature/max_temperature <<"%" <<endl;
    
    // Set Parameters
    InitializeSystem(init_cell,temperature,density);
    solid->initialize();

    // Equilibrium Loop
    for (int t = 0; t < n_equil; t++)
      Metropolis(solid);

    // Measure Loop      
    s_fmp = 0. ;
    ss_fmp = 0. ;

    initial_state->copy( solid );
    for (int t = 0; t < n_steps; t++)
    {	 
      // Evolve
      initial_state-> copy(solid);
      Metropolis(solid);

      // Measure Energy and FMP
      //      solid->measure();
      t_fmp = solid->get_fmp(initial_state);
      s_fmp += t_fmp;
      
      // Measure each 'stepAvg' steps
      if( t % stepAvg == 0 )
      {
	s_fmp += s_fmp / stepAvg;	 
	fmp += s_fmp;
	ss_fmp += fmp*fmp;	  
	s_fmp = 0.;
      }
    }
    
    // Calculate averages and error

    fmp = fmp / n_measures;
    err_fmp = (ss_fmp/n_measures - fmp*fmp) / n_measures;
    err_fmp = sqrt( abs( err_fmp ) );
      
    // Write to file
    out_file
      << temperature <<tab
      << fmp <<tab
      << err_fmp <<tab
      <<endl;
    
    temperature += incr_temperature;
  }
  out_file.close();  

  
  //////////////////////////////////////////////////////////////////////
  //////////////////////////////////////////////////////////////////////
  
  // Plots
  sys_cmd = system(plot_cmd);
 
  return 0;
}
