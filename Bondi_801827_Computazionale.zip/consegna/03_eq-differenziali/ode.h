#include <cmath>
#include <iostream>
#ifndef ODE
#define ODE

enum method {euler, rk, midpoint};

class ode
{
 public:
  // Constructors
  ode();
  ode( double* (*f)(double*,double) );
  ode( double* (*f)(double*,double), double* x0, double t0, double tf, int n_steps);
  ode( double* (*f)(double*,double), double* x0, double t0, double tf, double dt);
  ode(int n_dim,  double* (*f)(double*,double), double* x0, double t0, double tf, int n_steps);
  ode(int n_dim,  double* (*f)(double*,double), double* x0, double t0, double tf, double dt);
  ~ode();

  // General
  void set_function( double*(*f)(double*,double) );
  void set_init_conditions(double*, double);
  void set_final_time(double);
  void set_n_steps(int);
  void set_dt(double);
  double get_x(int);
  double get_t();
  void print();
  
  // Dynamics    
  void evolve(method);
  void evolve();
  void onestep();
  void onestep(method);
  // RK methods
  void euler_rule();         // First  order RK method
  void midpoint_rule(); // Second order RK method
  void runge_kutta();   // Fourth order RK method
    
 private:
  double *_x0;
  double *_xf;
  double *_x;
  
  double _t,_t0, _tf;
  double _dt;
  
  int _n_steps;
  int _n_dim;     // Number of variables of the problem
  double* (*_function)(double*,double);  // System x' = f(x,t)
};

//////////////////////////////////////////////////////////////////////
//                        Constructors                              //
//////////////////////////////////////////////////////////////////////
ode::~ode()
{
}

double* f_default(double* x,double t)
{
  double *y = x;
  *y *= -1;
  return y;
} 

ode::ode()
{
   _n_dim = 1;

   _t0 = 0.0;
  _t = _t0;
  _tf = 1.0; 

  _x0 = new double[_n_dim];
  _x = new double[_n_dim];
  _xf = new double[_n_dim];

  for(int k = 0; k<_n_dim ; k++)
  {
    _x0[k] = 0.0;
    _x[k] = _x0[k];
    _xf[k] = _x0[k];
  }
 
  // Evolution function
  _function = f_default;
  _dt = 0.01;
  _n_steps = int(_tf/_dt) + 1;
}

ode::ode(double* (*f)(double*,double))
{
  _n_dim = 1;
  
  _t0 = .0;
  _t = _t0;
  _tf = 1.; 

  _x0 = new double[_n_dim];
  _x = new double[_n_dim];
  _xf = new double[_n_dim];

  for(int k = 0; k<_n_dim ; k++)
  {
    _x0[k] = 0.0;
    _x[k] = _x0[k];
    _xf[k] = _x0[k];
  }

  // Evolution function
  _function = f;
  _dt = 0.01;
  _n_steps = int(_tf/_dt) + 1;

}

ode::ode(double* (*f)(double*,double), double *x0, double t0, double tf, int n_steps)
{
  _n_dim = 1;

  _t0 = t0;
  _t = _t0;
  _tf = tf; 
  _x0 = x0;
  _x = _x0;

  _x0 = new double[_n_dim];
  _x = new double[_n_dim];
  _xf = new double[_n_dim];

  for(int k = 0; k<_n_dim ; k++)
  {
    _x0[k] = x0[k];
    _x[k] = _x0[k];
    _xf[k] = _x0[k];
  }

  // Evolution function
  _function = f;
  _n_steps = n_steps;
  _dt = (_tf-_t0)/_n_steps;
  
}
ode::ode(double* (*f)(double*,double), double *x0, double t0, double tf, double dt)
{
  _n_dim = 1;

  _t0 = t0;
  _t = _t0;
  _tf = tf; 
  
  _x0 = new double[_n_dim];
  _x = new double[_n_dim];
  _xf = new double[_n_dim];

  for(int k = 0; k<_n_dim ; k++)
  {
    _x0[k] = x0[k];
    _x[k] = _x0[k];
    _xf[k] =_x0[k];
  }
  
  // Evolution function
  _function = f;
  _dt = dt;
  _n_steps = int(_tf/_dt) + 1;

}

ode::ode(int n_dim, double* (*f)(double*,double), double *x0, double t0, double tf, int n_steps)
{ 
  _n_dim = n_dim;

  _t0 = t0;
  _t = _t0;
  _tf = tf; 

  _x0 = new double[_n_dim];
  _x  = new double[_n_dim];
  _xf = new double[_n_dim];

  for(int k = 0; k<_n_dim ; k++)
  {
    _x0[k] = x0[k];
    _x[k] = _x0[k];
    _xf[k] = x0[k];
  }

  // Evolution function
  _function = f;
  _n_steps = n_steps;
  _dt = (_tf-_t0)/_n_steps;
}

ode::ode(int n_dim, double* (*f)(double*,double), double *x0, double t0, double tf, double dt)
{
  _n_dim = n_dim;

  _t0 = t0;
  _t = _t0;
  _tf = tf; 


  _x0 = new double[_n_dim];
  _x = new double[_n_dim];
  _xf = new double[_n_dim];

  for(int k = 0; k<_n_dim ; k++)
  {
    _x0[k] = x0[k];
    _x[k] = _x0[k];
    _xf[k] = x0[k];
  }

  // Evolution function
  _function = f;
  _dt = dt;
  _n_steps = int(_tf/_dt) + 1;

}

//////////////////////////////////////////////////////////////////////
//                          General                                 //
//////////////////////////////////////////////////////////////////////
void ode::set_function( double* (*f)(double*,double) )
{
  _function = f;
  return;
}

void ode::set_init_conditions(double *x0, double t0)
{
  for(int k=0 ; k<_n_dim ; k++)
    _x0[k] = x0[k];
  _t0 = t0;
  return;
}

void ode::set_final_time(double tf)
{
  _tf = tf;
  return;
}

void ode::set_n_steps(int n)
{
  _n_steps = n;
  return;
}

void ode::set_dt(double dt)
{
  _dt = dt;
  return;
}

double ode::get_x(int k)
{
  return _x[k];
}
double ode::get_t()
{
  return _t;
}

void ode::print()
{
  for(int k=0 ; k<_n_dim ; k++)
    std::cout <<"_x0["<<k<<"]: "<< _x0[k] <<std::endl;
  for(int k=0 ; k<_n_dim ; k++)
    std::cout <<"_x["<<k<<"]: "<< _x[k] <<std::endl;
  for(int k=0 ; k<_n_dim ; k++)
    std::cout <<"_xf["<<k<<"]: "<< _xf[k] <<std::endl;

    std::cout
    <<"_t0: "<< _t0 <<std::endl
    <<"_t: "<< _t <<std::endl
    <<"_tf: "<< _tf <<std::endl
    <<std::endl
    <<"_dt: "<< _dt <<std::endl
    <<"_n_steps: "<< _n_steps <<std::endl
    <<"_n_dim: "<< _n_dim <<std::endl
    <<std::endl;
}

//////////////////////////////////////////////////////////////////////
//                          Dynamics                                //
//////////////////////////////////////////////////////////////////////

void ode::evolve()
{
  evolve(rk);
  return;
}

void ode::evolve(method m)
{
  _t =_t0;
  _x = _x0;
  while( _t < _tf)
  {
    onestep(m);
  }
  _xf = _x;
  return;
}

void ode::onestep()
{
  onestep(rk);
  return;
}

void ode::onestep(method m)
{
  switch(m)
  {
    case euler:
      euler_rule(); break;
    case rk:
      runge_kutta(); break;
    case midpoint:
      midpoint_rule(); break;
  }  
  return;
}

//////////////////////////////////////////////////////////////////////
//                    Runge-Kutta methods                           //
//////////////////////////////////////////////////////////////////////

// First order Runge-Kutta method
void ode::euler_rule()
{
  double *xx = new double[_n_dim];
  xx = _function( _x , _t);
  
  for (int k=0 ; k<_n_dim ; k++)
    _x[k] += _dt * xx[k];
  _t += _dt;
  delete xx;
  return;
}

// Second order Runge-Kutta method
void ode::midpoint_rule()
{
  double *xx = new double[_n_dim];

  double* k1 = new double[_n_dim];
  double* k2 = new double [_n_dim];
  
  k1 = _function( _x , _t );
  for (int j=0 ; j<_n_dim ; j++)
    xx[j] = _x[j] + 0.5*_dt*k1[j];
  
  k2 = _function( xx , 0.5*_dt*_t );
  for (int j=0 ; j<_n_dim ; j++)  
    _x[j] += k2[j] * _dt;  // + O( _dt^3 )
  _t += _dt;

  delete k1;
  delete k2;
  delete xx;
  return;
}

// Fourth order Runge-Kutta method
void ode::runge_kutta()
{
  double *x1 = new double[_n_dim];
  double *x2 = new double[_n_dim];
  double *x3 = new double[_n_dim];
  
  double* k1 = new double[_n_dim];
  double* k2 = new double[_n_dim]; 
  double* k3 = new double[_n_dim];
  double* k4 = new double[_n_dim];

  k1 = _function( _x , _t );
  for (int j=0 ; j<_n_dim ; j++)
    x1[j] = _x[j] + 0.5*_dt*k1[j];

  k2 = _function( x1 , _t + 0.5*_dt );
  for (int j=0 ; j<_n_dim ; j++)
    x2[j] =  _x[j] + 0.5*_dt*k2[j];

  k3 = _function( x2 , _t + 0.5*_dt );
  for (int j=0 ; j<_n_dim ; j++)
    x3[j] =  _x[j] + 1.0*_dt*k3[j];
  k4 = _function( x3 , _t + 1.0*_dt );
  for (int j=0 ; j<_n_dim ; j++)
    _x[j] +=  _dt/6*( k1[j] + 2*k2[j] + 2*k3[j] + k4[j]);
  _t += _dt;

  delete k1;
  delete k2;
  delete k3;
  delete k4;
  delete x1;
  delete x2;
  delete x3;
  return;
}

#endif
