#include <cmath>
#ifndef ODE
#define ODE

#include <iostream>
using namespace std;
void test(int n)
{
  std::cout <<"Test "<<n <<std::endl;
  return;
}
enum method {euler, rk, midpoint};

class ode
{
 public:
  // Constructors
  ode();
  ode( double (*f)(double,double) );
  ode( double (*f)(double,double), double x0, double t0, double tf, int n_steps);
  ode( double (*f)(double,double), double x0, double t0, double tf, double dt);
  ode(int n_dim,  double (*f)(double,double), double x0, double t0, double tf, int n_steps);
  ode(int n_dim,  double (*f)(double,double), double x0, double t0, double tf, double dt);
  ~ode();

  // General
  void set_function( double(*f)(double,double) );
  void set_init_conditions(double, double);
  void set_final_time(double);
  void set_n_steps(int);
  void set_dt(double);
  double get_x();
  double get_t();
  void print();
  
  // Dynamics    
  void evolve(method);
  void evolve();
  void onestep();
  void onestep(method);
  // RK methods
  void euler_rule();         // First  order RK method
  void midpoint_rule(); // Second order RK method
  void runge_kutta();   // Fourth order RK method
    
 private:
  double _x0, _t0; // Initial conditions
  double _x, _t;
  double _xf, _tf; // Final conditions
  double _dt;
  int _n_steps;
  int _n_dim;     // Number of variables of the problem
  double (*_function)(double,double);  // System x' = f(x,t)
};

//////////////////////////////////////////////////////////////////////
//                        Constructors                              //
//////////////////////////////////////////////////////////////////////
ode::~ode()
{
}

double f_default(double x,double t)
{
    return -x;
} 

ode::ode()
{
   _n_dim = 1;
  // Initial conditions
  _x0 = 0.0;
  _t0 = 0.0;
  _x = _x0;
  _t = _t0;
  // Final conditions
  _xf = _x0; // Set it to _x0 so it is not undefined
  _tf = 1.0; 
  _dt = 0.01;
  _n_steps = int(_tf/_dt) + 1;
  // Evolution function
  _function = f_default; 
}

ode::ode(double (*f)(double,double))
{
  _n_dim = 1;
  // Initial conditions
  _x0 = 0.0;
  _t0 = 0.0;
  _x = _x0;
  _t = _t0;
  // Final conditions
  _xf = _x0; // Set it to _x0 so it is not undefined
  _tf = 1.0; 
  _dt = 0.01;
  _n_steps = int(_tf/_dt) + 1;
  // Evolution function
  _function = f;  
}

ode::ode(double (*f)(double,double), double x0, double t0, double tf, int n_steps)
{
  _n_dim = 1;
  // Initial conditions
  _x0 = x0;
  _t0 = t0;
  _x = _x0;
  _t = _t0;
  // Final conditions
  _xf = _x0; // Set it to _x0 so it is not undefined
  _tf = tf; 
  _n_steps = n_steps;
  _dt = (_tf-_t0)/_n_steps;
  // Evolution function
  _function = f;  
}
ode::ode(double (*f)(double,double), double x0, double t0, double tf, double dt)
{
  _n_dim = 1;
  // Initial conditions
  _x0 = x0;
  _t0 = t0;
  _x = _x0;
  _t = _t0;
  // Final conditions
  _xf = _x0; // Set it to _x0 so it is not undefined
  _tf = tf; 
  _dt = dt;
  _n_steps = int(_tf/_dt) + 1;
  // Evolution function
  _function = f; 
}

ode::ode(int n_dim, double (*f)(double,double), double x0, double t0, double tf, int n_steps)
{
  double dt = tf / n_steps;
  _n_dim = n_dim;
  // Initial conditions
  _x0 = x0;
  _t0 = t0;
  _x = _x0;
  _t = _t0;
  // Final conditions
  _xf = _x0; // Set it to _x0 so it is not undefined
  _tf = tf; 
  _dt = dt;
  _n_steps = n_steps;
  // Evolution function
  _function = f;
}

ode::ode(int n_dim, double (*f)(double,double), double x0, double t0, double tf, double dt)
{
  _n_dim = n_dim;
  // Initial conditions
  _x0 = x0;
  _t0 = t0;
  _x = _x0;
  _t = _t0;
  // Final conditions
  _xf = _x0; // Set it to _x0 so it is not undefined
  _tf = tf; 
  _dt = dt;
  _n_steps = int(_tf/_dt) + 1;
  // Evolution function
  _function = f;
}

//////////////////////////////////////////////////////////////////////
//                          General                                 //
//////////////////////////////////////////////////////////////////////
void ode::set_function( double (*f)(double,double) )
{
  _function = f;
  return;
}

void ode::set_init_conditions(double x0, double t0)
{
  _x0 = x0;
  _t0 = t0;
  return;
}

void ode::set_final_time(double tf)
{
  _tf = tf;
  return;
}

void ode::set_n_steps(int n)
{
  _n_steps = n;
  return;
}

void ode::set_dt(double dt)
{
  _dt = dt;
  return;
}

double ode::get_x()
{
  return _x;
}
double ode::get_t()
{
  return _t;
}
void ode::print()
{
  std::cout
    <<std::endl
    <<"_x0: "<< _x0 <<std::endl
    <<"_t0: "<< _t0 <<std::endl
    <<"_x: "<< _x <<std::endl
    <<"_t: "<< _t <<std::endl
    <<"_xf: "<< _xf <<std::endl
    <<"_tf: "<< _tf <<std::endl
    <<"_dt: "<< _dt <<std::endl
    <<"_n_steps: "<< _n_steps <<std::endl
    <<"_n_dim: "<< _n_dim <<std::endl
    <<std::endl;
}

//////////////////////////////////////////////////////////////////////
//                          Dynamics                                //
//////////////////////////////////////////////////////////////////////

void ode::evolve()
{
  evolve(rk);
  return;
}

void ode::evolve(method m)
{
  _t =_t0;
  _x = _x0;
  while( _t < _tf)
  {
    onestep(m);
  }
  _xf = _x;
  return;
}

void ode::onestep()
{
  onestep(rk);
  return;
}

void ode::onestep(method m)
{
  switch(m)
  {
    case euler:
      euler_rule(); break;
    case rk:
      runge_kutta(); break;
    case midpoint:
      midpoint_rule(); break;
  }  
  return;
}

//////////////////////////////////////////////////////////////////////
//                    Runge-Kutta methods                           //
//////////////////////////////////////////////////////////////////////

// First order Runge-Kutta method
void ode::euler_rule()
{
  _x += _dt * _function( _x , _t);
  _t += _dt;
  return;
}

// Second order Runge-Kutta method
void ode::midpoint_rule()
{
  double k1,k2;
  k1 = _function( _x , _t );
  k2 = _function( _x + 0.5*_dt*k1 , 0.5*_dt*_t );
  _t += _dt;
  _x += k2 * _dt;  // + O( _dt^3 )
  return;
}

// Fourth order Runge-Kutta method
void ode::runge_kutta()
{
  double k1,k2,k3,k4;
  k1 = _function( _x , _t );
  k2 = _function( _x + 0.5*_dt*k1 , _t + 0.5*_dt );
  k3 = _function( _x + 0.5*_dt*k2 , _t + 0.5*_dt );
  k4 = _function( _x + 1.0*_dt*k3 , _t + 1.0*_dt );
  _t += _dt;
  _x +=  _dt/6*( k1 + 2*k2 + 2*k3 + k4);
  return;
}

#endif
