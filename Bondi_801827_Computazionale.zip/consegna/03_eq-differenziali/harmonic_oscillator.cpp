#include <iostream>
#include <fstream>
#include "ode.h"

using namespace std;

double* f(double* x, double t)
{
  double *y = new double[2];
  double omega = 1.0;
  y[0] = x[1];
  y[1] = -omega*omega*x[0];

  return y;
}

int main()
{
  int dim = 2;
  // Plot
  const char* filename = "harm-osc.data";
  ofstream out_file;
  int sys;
  
  double *x0 = new double[dim];
  double t0 = 0. , tf = 20. ;
  double t = 0., dt = 0.05;
  double x2, x4, v2, v4;
  double err2 = 0., err4 = 0.;
  int n = 0;
  double y;
  
  // Initial conditions
  x0[0] = 1.0;  // x[0] = position
  x0[1] = 0.0;  // x[1] = velocity    
 
  ode harm2(dim,f,x0,t0,tf,dt);
  ode harm4(dim,f,x0,t0,tf,dt);

  out_file.open(filename);
  while(t<tf)
  {
    n++;
    harm2.onestep(midpoint);
    harm4.onestep(rk);
    x2 = harm2.get_x(0);
    v2 = harm2.get_x(1);
    x4 = harm4.get_x(0);
    v4 = harm4.get_x(1);
    y = cos(t);
    err2 += (x2-y)*(x2-y);
    err4 += (x4-y)*(x4-y);
    
    out_file
      <<t <<"\t"
      <<x2 <<"\t"
      <<v2 <<"\t"
      <<x4 <<"\t"
      <<v4 <<"\t"
      <<endl;
    t += dt;
  }
  out_file.close();
  
  err2 = sqrt(err2/n);
  err4 = sqrt(err4/n);
  cout <<"err2" <<"\t" <<"err4" <<endl;
  cout <<err2 <<"\t" <<err4 <<endl;
  //  sys = system( "gnuplot -p harm-osc.gnu" );
  return 0;
}

