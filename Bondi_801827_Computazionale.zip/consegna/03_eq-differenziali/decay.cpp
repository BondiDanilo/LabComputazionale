#include <iostream>
#include "odeI.h"

using namespace std;

double f(double x, double t)
{
  double mu = 0.05;
  return -mu*x;
}

int main()
{
  double x0 = 10, t0 = 0. , tf = 20. , dt = 0.001;
  double y = 3.678794412;
  ode decay1(1,f,x0,t0,tf,dt);
  ode decay2(1,f,x0,t0,tf,dt);
  ode decay4(1,f,x0,t0,tf,dt);

  while(dt<2)
  {
    decay1.set_dt(dt);
    decay2.set_dt(dt);
    decay2.set_dt(dt);
    
    decay1.evolve(euler);
    decay2.evolve(midpoint);
    decay4.evolve(rk);

    cout
      <<dt <<" & "
      <<decay1.get_x() <<" & "
      <<abs( y-decay1.get_x() ) <<" & "
      <<decay2.get_x() <<" & "
      <<abs( y-decay2.get_x() ) <<" & "
      <<decay4.get_x() <<" & "
      <<abs( y-decay4.get_x() ) <<"\\\\"
	    <<endl;
    dt *= 10;
  }

  return 0;
}

