#include <cmath>
#include <iostream>
#include <vector>

//using namespace std;

#ifndef INTEGRAL
#define INTEGRAL

class Integral{
 private:
  double _integral, _error;
  double _x_min, _x_max;
  int _n_points;
  // Monte Carlo Integration
  double * _grid;     // vector of dimension _n_points+1: from 0 to _n_points
  double * _step_function;
  double * _cumulant;   // Cumulative function
  
 public:
  Integral();
  ~Integral();
  Integral(int);
  Integral(double,double,int);

  void set_n(int);
  void set_boundaries(double,double);
  double get_integral();
  double get_error();
  double simpson(double (*f)(double));
  double adaptive(double (*f)(double),double,double,double,double);
  double adaptive_simpson(double (*f)(double),double,double);
  
  //////////////////////////////////////////////////
  //           Monte Carlo Integration            //
  //////////////////////////////////////////////////
  double generation(double (*f)(double));
  void adaptive_montecarlo( double (*f)(double) );
  void print_grid();
  void initialize_grid();
  void set_grid(std::vector <double>);
  void save_grid(std::vector <double>);
  double h_function(double);
  void plot_hfunc();
};

//////////////////////////////////////////////////////////////////////
//                      Constructors                                //
//////////////////////////////////////////////////////////////////////
Integral::Integral()
{
  _x_min = 0.0;
  _x_max = 1.0;
  _n_points = 10;
  _integral = 0.0;
  _error = 0.0;
  // Monte Carlo
  _grid = new double[_n_points];
  _step_function = new double[_n_points];
  _cumulant = new double[_n_points+1];
  initialize_grid();
}

Integral::Integral(int n)
{
  _x_min = 0.0;
  _x_max = 1.0;
  _n_points = n;
  _integral = 0.0;
  _error = 0.0;
    // Monte Carlo
  _grid = new double[_n_points+1];
  _step_function = new double[_n_points];
  _cumulant = new double[_n_points+1];
  initialize_grid();
}

Integral::Integral(double x_min,double x_max, int n)
{
  _x_min = x_min;
  _x_max = x_max;
  _n_points = n;
  _integral = 0.0;
  _error = 0.0;
  // Monte Carlo
  _grid = new double[_n_points+1];
  _step_function = new double[_n_points];
  _cumulant = new double[_n_points+1];
  initialize_grid();
}

Integral::~Integral()
{
  delete _grid;
  delete _cumulant;
}

//////////////////////////////////////////////////////////////////////
//                     Simpson Method                               //
//////////////////////////////////////////////////////////////////////

double simpson_rule( double (*f)(double), double a, double b)
{
  return (b-a)/6 * ( f(a) + f(b) + 4*f( 0.5*(a+b) ) );
}

double Integral::simpson( double (*f)(double) )
{
  double I = 0.0;
  double dx = (_x_max- _x_min) / (2*_n_points); // 2N sottointervalli

  double a,b; // Estremi del sottointervallo
  for (int k=0 ; k < 2*_n_points+1 ; k++)
  {
    if ( k%2 == 0)
    { // estremo del sottointervallo
      a = _x_min + dx*k;

      if ( k!=0 && k != 2*_n_points )
	I += (2./3.)*dx*f(a); // ad ogni estremo conto la funzione due volte
      else
	I += (1./3.)*dx*f(a); // tranne quando si tratta dell'estremo iniziale
    }
    if (k%2==1)
    { // nodo centrale del sottointervallo
      b = _x_min + dx*k;
      I = I + (4./3.) * dx * f(b);
    }
  }
  _integral = I;
  return _integral;
}

double Integral::adaptive(double (*f)(double),double a, double b, double abs_err, double rel_err)
{
  double I = 0.0, J = 0.0,  error = 0.0;
  double c = 0.5*(a+b); //Midpoint
    
  I = simpson_rule(f,a,b);
  J = simpson_rule(f,a,c) + simpson_rule(f,c,b);
  // simpson integral with double the points

  // The error of the method is taken to be less than the
  // maximum between the absolute and relative error parameters
  if (abs_err >= I*rel_err)
    error = 0.9*abs_err;
  else
    error = 0.9*I*rel_err;
  
  // Recursion
  if( abs(I-J) < error )
    I = J;
  else
  {
    error = error*0.5;
    // Think about an appropriate choice for the error
    I = this->adaptive(f,a,c,error,0.0) + this->adaptive(f,c,b,error,0.0);
  }
  _error = error;
  _integral = I;
  return I;
}

double Integral::adaptive_simpson(double (*f)(double), double abs_err, double rel_err)
{
  _integral = adaptive(f,_x_min,_x_max, abs_err, rel_err);
  return _integral;
}

//////////////////////////////////////////////////////////////////////

double Integral::get_integral()
{
  return _integral;
}

double Integral::get_error()
{
  return _error;
}

void Integral::set_n(int n)
{
  _n_points = n;
  return;
}
void Integral::set_boundaries(double x_min, double x_max)
{
  _x_min = x_min;
  _x_max = x_max;
  return;
}

//////////////////////////////////////////////////////////////////////
//                   Monte Carlo Integration                        //
//////////////////////////////////////////////////////////////////////
void Integral::plot_hfunc()
{
  int sys;
  // Export hfunc to file
  /* Code */
  // Plot
  sys = system("gnuplot -p hfunc.gnu");
  return;
}

void Integral::print_grid()
{
  std::cout <<"Integration grid:" <<std::endl;
  for (int i=0 ;  i<_n_points ; i++)
    std::cout <<"x["<<i<<"]"<<" = " <<_grid[i] <<std::endl;
  std::cout <<std::endl;
  return;
}

void Integral::initialize_grid()
{
  for (int i=0 ;  i<_n_points+1 ; i++)
  {
    _grid[i] = _x_min + (_x_max - _x_min) * (double)i / _n_points;
    _cumulant[i] = 0.0;
    _step_function[i] = 0.0;
  }
  return;
}

void Integral::set_grid(std::vector <double>  new_grid)
{
  if (new_grid.size() == _n_points)
    for (int i=0 ;  i<_n_points ; i++)
      _grid[i] = new_grid[i];
  else
  {
    std::cout
      <<"ERROR: In Integral::set_grid(std::vector<double> new_grid) "<<std::endl
      <<"'new_grid' should have the same size of the exixting grid vector." <<std::endl
      <<"Size of existing grid is: " <<_n_points <<std::endl
      <<"Operation killed." <<std::endl;
  }
  return;
}

void Integral::save_grid(std::vector <double>  new_grid)
{
  if (new_grid.size() == _n_points)
    for (int i=0 ;  i<_n_points ; i++)
      new_grid[i] = _grid[i];
  else
  {
    std::cout
      <<"ERROR: In Integral::save_grid(std::vector<double> new_grid) "<<std::endl
      <<"'new_grid' should have the same size of the exixting grid vector." <<std::endl
      <<"Size of existing grid is: " <<_n_points <<std::endl
      <<"Operation killed." <<std::endl;
  }
  return;
}

double Integral::h_function(double y)
{
  // The function x = h(y) is taken do be a
  // piecewise linear function between y in [0,1]
  // and the points of the grid x in [x_min,x_max]
  int k;
  double dx = 0.0, h = 0.0;

  // Since y are uniformly distributed in [0,1]
  // dy = 1/ _n_points    =>    _n_points = 1/dy
  
  // Find index k of the subinterval that contains y
  k = int(y*_n_points);  // (int) y/dy
  
  dx = _grid[k+1] - _grid[k];

  // dy = 1.0 / _n_points  since y are uniformly distributed in [0,1]
  h = _grid[k] + dx * _n_points * ( y - (double)k/_n_points );
  // h now lies on the straight line between x[k-1] and x[k]
  return h;
}

double linearize (double x, double xa, double xb, double ya, double yb)
{
  return ya + (x-xa)*(yb-ya)/(xb-xa);
}

void Integral::adaptive_montecarlo( double (*f)(double) )
{
  // We generate uniform random numbers y in [0,1], then we turn them in
  // f-distributed random numbers x in [x_min,x_max] via a function h
  //     (i.e.) x = h(y) in [x_min,x_max] is distributed according to f

  double a = _x_min;
  double b = _x_max; 
  
  int n = 10000;        // Number of random extractions
  int m = _n_points;    // Number of subintervals
  
  double delta_x = (b-a)/m; 
  double y[n];          // Array of random points
  double delta_y = 1./m;

  double X[m+1];        // Old points of the grid
  double X_new[m+1];    // New points of the grid
  double Y[m+1];        // Boundary points of uniform y subintervals

  for (int i=0; i<m+1;i++)
  {
    Y[i] = delta_y*i;
    X[i] = _grid[i]; 
  }

  //  print_grid();
  
  double tollerance = 0.001;
  
  double I[m+1],R[m],N[m];  // Integral, Number of points, Integral function
                            // in each subinterval
  int k;
  double _I;
  int L;      // Index of the interval matching the required condition
  double I_L;
  double subinterval_error = 1.1*tollerance;
     // Start by having it a little bigger than tollerance to enter the loop
  double _II;
  double integrand;
  double S[m];
  
  // First, we have to determine a dedicated function h
  // Given f, we require that
  //        f( h(y) ) * dh(y)/dy = const
  // In particular, let R_l be the integral in the subinterval [ x_l , x_l+1 ]

  // We would like R_l to be constant. With this purpose, we keep iterating
  // the adaptive process until
  //       max_ij(|R_i - R_j|) < tollerance
  
  //////////////////////////////////////////////////
  //             Adapt the grid                   //
  //////////////////////////////////////////////////
  //                                              //
  // The process of adapting the grid lets us     //
  // determine the function                       //
  //     h : y in [0,1] -> x in [x_min,x_max]     //
  //////////////////////////////////////////////////
  

  // Condition:    max_j(|R_j - R_j+1|) < tollerance
  while (subinterval_error>tollerance)
  {
    _I = 0;
    _II = 0;

    // We generate uniform random points in y
    for(int i=0;i<n;i++) 
      y[i] = double(rand())/RAND_MAX;
   
    for(int i=0;i<m;i++)
    {
      R[i]=0;
      N[i]=0;
      I[i]=0;
      S[i]=0;
    }
    I[m]=0;

    for (int i=0;i<n;i++)
    {
      // Find in which interval k the random point y is found
      k = int(y[i]/delta_y);
      // Then evaluate the integral in x = h(y)
      R[k] += f( linearize( y[i] , Y[k] , Y[k+1] , X[k] , X[k+1]) ) * (X[k+1]-X[k]);
      //R[k] += f( h_function(y) ) * ( _grid[k] - _grid[k-1] ); // with Jacobian
      N[k] += 1;
    }
    // Then we accumulate in I[k] the integral function from x_0 to x_k
    for(int i=1;i<m+1;i++) 
      for(int j=0;j<i;j++) 
	I[i]+=R[j]/N[j]; 

    // We find new points x_k for the grid such that
    //           I[k] = I[_n_points] * k/_n_points
    // This should give rise to the condition we are really looking for
    //              f( h(y) ) * dh(y)/dy = const
    for(int l=1;l<m+1;l++)
    {
      I_L=(double(l)/m)*I[m];  // Now we invert this condition
      
      // First, find the index l of the subinterval such that
      //      I[l] <= I[k] <= I[l+1]
      for(int j=0;j<m;j++)
      {
	if (I[j]<=I_L && I_L<=I[j+1])
	{
	  L=j+1;
	  break;
	  //j=m;
	} 
      }
      
      // Evaluate the new points of the grid
      X_new[l] = X[L-1] + ( (X[L]-X[L-1] ) / ( I[L]-I[L-1]) ) * ( I[m]*l/m-I[L-1] );
    }
    
    // Update the new grid
    for(int l=1;l<m+1;l++)
    {
      X[l] = X_new[l];
      _grid[l] = X[l];
    }
    
    //////////////////////////////////////////////////
    //          Calculating the integral            //
    //////////////////////////////////////////////////
    for(int i=0;i<n;i++) {
      k = int(y[i]/delta_y);
      integrand = f( linearize( y[i], Y[k], Y[k+1], X[k], X[k+1]) );
      if (integrand > S[k]) {
	S[k]= integrand;
      }
      integrand = integrand*(X[k+1]-X[k])/(Y[k+1]-Y[k]);
      _I += (1./n)*integrand;
      _II += integrand*integrand;
    }
	
    subinterval_error = 0.0;
    
    for (int i=0;i<m;i++) 
      for(int j=0;j<i;j++) 
	if( abs( R[i]/N[i] - R[j]/N[j] ) > subinterval_error ) 
	  subinterval_error = abs(R[i]/N[i]-R[j]/N[j]);      
  }

  _II = _II / n;
  
  _integral = _I;
  _error = sqrt( abs(_II - _I*_I) / n );
  
  //////////////////////////////////////////////////
  //        Generating f-distribution             //
  //////////////////////////////////////////////////

  double T[m+1];
  T[0] = 0;

  // Slightly scale the S function so it is really bigger than f
  for (int i=0;i<m;i++) 
    S[i]=1.2*S[i]; 

  // Cumulant function
  for (int l=1;l<m+1;l++) 
    for (int j=0;j<l;j++) 
      T[l] += S[j]*(X[j+1]-X[j]);

  // Save the cumulant and step functions
  for (int l=0 ; l<m+1 ; l++)
    _cumulant[l] = T[l];
  
  for (int l=0 ; l<m ; l++)
    _step_function[l] = S[l];
 
  return;
}

double Integral::generation(double (*f)(double))
{
  int m = _n_points;
  int n = 10000;
  double T[m+1],S[m], X[m+1];
  double x,r,rr;

  //  int n_entries;
  int n_reject = 0;
  int l;
  //double s = 0.0;
  bool accept = 0;

  // Get cumulant and step function
  for (int l=0 ; l<m+1 ; l++)
  {
    X[l] = _grid[l];
    T[l] = _cumulant[l];
  }
  
  //  for (int i=0 ; i<n ;i++)
  while( accept != 1)
  {
    r = double(rand())/RAND_MAX;
    // if (r<T[1]/T[m])
    //s = s+1; //
  
    for(int j=0;j<m+1;j++)
    {  
      if(T[j]/T[m]>r)
      {
	l = j;
	j = m+1; 
      }
    }
    
    // Get the extracted number
    x = X[l-1]+(r-T[l-1]/T[m])/(T[l]/T[m]-T[l-1]/T[m])*(X[l]-X[l-1]);
    
    rr = double(rand())/RAND_MAX;
    if (rr*_step_function[l-1] <= f(x) )
    { 
      //      n_entries++;
      accept = 1;
    }
    else {
      n_reject += 1;
    }
  }

  std::cout << "n_reject= " << n_reject << std::endl;

  return x;
}
#endif
