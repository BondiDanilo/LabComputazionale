#include "../multi-integral.h"
#include <string>
#include <cmath>
#include <ctime>

using namespace std;

double f(double xx[])
{
  double x = xx[0] , y = xx[1];
  return exp(x)*exp(y)/pow(exp(1)-1,2) ;
}

double g(double xx[])
{
  // Function with integrable singularity in (0.5,0.5)
  double x = xx[0] , y = xx[1];
  return 1.0 / sqrt( pow( x-0.5 ,2) + pow( y-0.5 ,2) );
}

int main()
{
  srand(time(NULL));
  string func;
    
  double I = 0.0 , I_exact = 0.0 , error = 0.0;
  int n = 10 , n_dim = 2;
  
  MultiIntegral integral(n,n_dim);
  
  // Regular function
  integral.adaptive_montecarlo(f);
  I_exact = 1.0000;
  error = integral.get_error();
  cout <<integral.get_integral() <<"\t"
       <<" $\\pm$ " <<"\t"
       <<error <<"\t"
       <<" & " <<"\t"
       <<I_exact <<"\t"
       <<" \\\\" <<endl;
  
  // Singular function
  integral.adaptive_montecarlo(g);
  I_exact = 3.5254943;
  error = integral.get_error();
  cout <<integral.get_integral() <<" $\\pm$ " <<error <<" & " <<I_exact <<" \\\\" <<endl;
  
  integral.plot_grid();
  
  return 0;
}
