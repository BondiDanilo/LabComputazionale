#include "../integral.h"
#include <string>
using namespace std;

double fx(double x)
{
  return 2*x;
}

double fxx(double x)
{
  return 3*x*x;
}

double fe(double x)
{
  return exp(x);
}

double fgauss(double x)
{
  return exp(-x*x);
}

double flog(double x)
{
  return log(x);
}

double isqrt(double x)
{
  return 1.0 / sqrt( abs(x-0.5) );
}


int main()
{
  string func;
    
  double I = 0.0 , I_exact = 0.0 , error = 0.0;
  int n = 10;
  double x;
  Integral integral(n);
  Integral sing_integral(n,0,1.0);
  
   cout
    << "    $f(x)$  &  Integral  & Real Value  \\\\ " <<endl
    << "    \\hline" <<endl;

  // f(x) = 2x
  func = "$2x$";
  integral.adaptive_montecarlo(fx);
  I = integral.get_integral();
  error = integral.get_error();
  I_exact = 1.000;
  cout <<func <<" & " <<I <<" $\\pm$ " <<error <<" & " <<I_exact <<" \\\\"  <<endl;

  // f(x) = 3x^2
  func = "$3x^2$";
  integral.adaptive_montecarlo(fxx);
  I = integral.get_integral();
  error = integral.get_error();
  I_exact = 1.000;
  cout <<func <<" & " <<I <<" $\\pm$ " <<error <<" & " <<I_exact <<" \\\\"  <<endl;
  

  // f(x) = exp(x)
  func = "$e^x$";
  integral.adaptive_montecarlo(fe);
  I = integral.get_integral();
  error = integral.get_error();
  I_exact = 1.7183;
  cout <<func <<" & " <<I <<" $\\pm$ " <<error <<" & " <<I_exact <<" \\\\"  <<endl;

  // f(x) = exp(-x^2)
  func = "$\\exp(-x^2)$";
  integral.adaptive_montecarlo(fgauss);
  I = integral.get_integral();
  error = integral.get_error();
  I_exact = 0.746824;
  cout <<func <<" & " <<I <<" $\\pm$ " <<error <<" & " <<I_exact <<" \\\\"  <<endl;

  // f(x) = log(x)
  func = "$\\log(x)$";
  sing_integral.adaptive_montecarlo(flog);
  I = sing_integral.get_integral();
  error = sing_integral.get_error();
  I_exact = -1.000;
  cout <<func <<" & " <<I <<" $\\pm$ " <<error <<" & " <<I_exact <<" \\\\"  <<endl;

  // f(x) = 1 / sqrt( abs(x-0.5) )
  func = "$1/\\sqrt{|x-0.5|}$";
  sing_integral.adaptive_montecarlo(isqrt);
  I = sing_integral.get_integral();
  I_exact = 2.82843;
  cout <<func <<" & " <<I <<" $\\pm$ " <<error <<" & " <<I_exact <<" \\\\"  <<endl;
  
  return 0;
}
