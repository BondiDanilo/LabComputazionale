#include "integral.h"
#include <iostream>
#include <fstream>
#include <string>

#include <cmath>

const char * tab = "\t";

using namespace std;

double fx(double x)
{
  return 2*x;
}

double fxx(double x)
{
  return 3*x*x;
}

double fe(double x)
{
  return exp(x);
}

double fgauss(double x)
{
  return exp(-x*x);
}

double flog(double x)
{
  return log(x);
}

double isqrt(double x)
{
  return 1.0 / sqrt( abs(x-0.5) );
}


int main()
{
  ofstream outfile;
  const char * filename = "simpson.data";
  const char * plot_cmd = "gnuplot -p simpson.gnu";
  int sys;

  string func;

  int n = 10, n_max = 50;
  double I = 0.0 , I_exact = 0.0 , error = 0.0;
  
  Integral integral(n);
  Integral sing_integral(n,0.001,1.0);

  cout
    << "    $f(x)$  &  Integral  & Real Value  \\\\ " <<endl
    << "    \\hline" <<endl;

  // f(x) = 2x
  func = "$2x$";
  I = integral.simpson(fx);
  I_exact = 1.000;
  cout <<func <<" & " <<I <<" & " <<I_exact <<" \\\\"  <<endl;

  // f(x) = 3x^2
  func = "$3x^2$";
  I = integral.simpson(fxx);
  I_exact = 1.000;
  cout <<func <<" & " <<I  <<" & " <<I_exact <<" \\\\"  <<endl;

  // f(x) = exp(x)
  func = "$e^x$";
  I = integral.simpson(fe);
  I_exact = 1.7183;
  cout <<func <<" & " <<I  <<" & " <<I_exact <<" \\\\"  <<endl;

  // f(x) = exp(-x^2)
  func = "$\\exp(-x^2)$";
  I = integral.simpson(fgauss);
  I_exact = 0.746824;
  cout <<func <<" & " <<I  <<" & " <<I_exact <<" \\\\"  <<endl;

  // f(x) = log(x)
  func = "$\\log(x)$";
  I = sing_integral.simpson(flog);
  error = sing_integral.get_error();
  I_exact = -1.000;
  cout <<func <<" & " <<I  <<" & " <<I_exact <<" \\\\"  <<endl;

  // f(x) = 1 / sqrt( abs(x-0.5) )
  func = "$1/\\sqrt{|x-0.5|}$";
  I = sing_integral.simpson(isqrt);
  I_exact = 2.82843;
  cout <<func <<" & " <<I <<" & " <<I_exact <<" \\\\"  <<endl;

  // Write file to plot
  I_exact = exp(1)-1.0;
  n = 10;
  outfile.open(filename);
  while ( n < n_max )
  {
    integral.set_n(n);
    I = integral.simpson(fe);
    error = abs(I-I_exact);
    outfile
      <<n <<tab
      <<error <<endl;
    /* Code */
      n += 1;
  }
  outfile.close();

  //sys = system(plot_cmd);
  return 0;
}
