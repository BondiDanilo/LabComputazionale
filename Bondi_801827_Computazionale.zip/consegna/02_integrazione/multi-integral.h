#include <cmath>
#include <iostream>
#include <vector>
#include <fstream>

using namespace std;

#ifndef MULTI_INTEGRAL
#define MULTI_INTEGRAL

class MultiIntegral{
 private:
  double _integral, _error;
  double _x_min, _x_max;
  int _n_points;
  int _n_dim;
  double ** _grid;     // vector of dimension _n_points+1: from 0 to _n_points
  
 public:
  MultiIntegral();
  ~MultiIntegral();
  MultiIntegral(int,int);
  MultiIntegral(double,double,int,int);

  void set_n(int);
  void set_boundaries(double,double);
  double get_integral();
  double get_error();
  
  //////////////////////////////////////////////////
  //           Monte Carlo Integration            //
  //////////////////////////////////////////////////
  void adaptive_montecarlo( double (*f)(double[]) );
  void print_grid();
  void plot_grid();
  void initialize_grid();
  void plot_hfunc();
};

//////////////////////////////////////////////////////////////////////
//                      Constructors                                //
//////////////////////////////////////////////////////////////////////
MultiIntegral::MultiIntegral()
{
  _n_dim = 1;
  _n_points = 10;
  _integral = 0.0;
  _error = 0.0;

  // Initialize boundaries
  _x_min = 0.0;
  _x_max = 1.0;
  
  initialize_grid();
}

MultiIntegral::MultiIntegral(int n_points,int n_dim)
{
  _n_dim = n_dim;
  _n_points = n_points;
  _integral = 0.0;
  _error = 0.0;
  // Initialize boundaries
  _x_min = 0.0;
  _x_max = 1.0;
      
  initialize_grid();
}

MultiIntegral::MultiIntegral(double x_min,double x_max, int n_points, int n_dim)
{
  _n_dim = n_dim;
  _n_points = n_points;
  _integral = 0.0;
  _error = 0.0;
  // Initialize Boundaries  
  _x_min = x_min;
  _x_max = x_max;
  
  initialize_grid();
}

MultiIntegral::~MultiIntegral()
{
  delete _grid;
}

//////////////////////////////////////////////////////////////////////
//                         General                                  //
//////////////////////////////////////////////////////////////////////

double MultiIntegral::get_integral()
{
  return _integral;
}

double MultiIntegral::get_error()
{
  return _error;
}

void MultiIntegral::set_n(int n_points)
{
  _n_points = n_points;
  return;
}

void MultiIntegral::set_boundaries(double x_min, double x_max)
{
  for(int k=0 ; k<_n_dim ; k++)
  {
    _x_min = x_min;
    _x_max = x_max;
  }
  return;
}

//////////////////////////////////////////////////////////////////////
//                   Monte Carlo Integration                        //
//////////////////////////////////////////////////////////////////////
void MultiIntegral::plot_hfunc()
{
  int sys;
  // Export hfunc to file
  /* Code */
  // Plot
  sys = system("gnuplot -p hfunc.gnu");
  return;
}

void MultiIntegral::print_grid()
{
  cout <<"Integration grid:" <<endl;
  
  for (int i=0; i<_n_points+1 ; i++)
  {
    cout <<"( ";
    for (int k=0; k<_n_dim ; k++)
    {
      cout <<_grid[i][k] <<" , ";
    }
    cout <<" )" <<endl;
  }
  return;
}

void MultiIntegral::initialize_grid()
{
  double delta_x;
  // Initialize Grid 
  _grid = new double*[_n_points+1];
  for (int i = 0; i<_n_points+1; i++)
    _grid[i] = new double[_n_dim];
  
  for (int k = 0; k<_n_dim; k++)
  {
    delta_x = ( _x_max - _x_min ) / _n_points;
    for (int i = 0; i<_n_points+1; i++)
      _grid[i][k] = _x_min + delta_x * i;
  }
  return;
}

double mod (double v[], int d) {
  double x=0;
  for(int i=0;i<d;i++) {
    x += v[i]*v[i];
  }
  return x;
}

double h_function (double x, double x1, double x2, double y1, double y2) {

  double k = (y2-y1)/(x2-x1);
  return y1+k*(x-x1);

}

void MultiIntegral::adaptive_montecarlo( double (*f)(double[]) )
{
  // We generate uniform random numbers y in [0,1], then we turn them in
  // f-distributed random numbers x in [x_min,x_max] via a function h
  //     (i.e.) x = h(y) in [x_min,x_max] is distributed according to f
  
  int count = 0;
  int loop_exit = 1000;
  srand(time(NULL));
  
  int d = _n_dim; 
  int n = 1000;   // Number of random extractions
  int m = _n_points;     // Subintervals

  double delta_x = (_x_max-_x_min) / m;
  double delta_y = 1.0 / m;
  double y[n][d]; // Vector of random points

  double X[m+1][d]; // Grid axis
  double X_new[m+1][d]; 
  double Y[m+1][d]; // Uniform numbers in [0,1]^d


  // Initialize Grid vectors
  for (int i=0; i<m+1;i++)
  {
    for(int j=0;j<d;j++)
    {
      Y[i][j] = delta_y*i ;
      X[i][j] = delta_x*i ; 
    }
  }
 
  double tollerance = 0.001; 
  
  double I[m+1][d],R[m][d],N[m][d];
  int k[2];
  double Int;
  int L;
  double I_L;
  double int_err[d];
  int_err[0] = tollerance+1;
  double IInt;
  double integrand;
  double S[m][d];
  double h[d];
  //  int sigma[d];
  double jacobian;

  while (mod(int_err,d) > pow(tollerance,d))
  {
    //////////////////////////////////////////////////
    // Exit condition if it gets in an infinite loop//
    //////////////////////////////////////////////////
    count ++;
    if(count > loop_exit)
    {
      cout <<"Exit counter exceeded." <<endl;
      break;
    }
    //////////////////////////////////////////////////
    //              Initialization                  //
    //////////////////////////////////////////////////
    Int = 0;
    IInt = 0;
    for(int i=0;i<n;i++)
    {
      for(int j=0;j<d;j++)
      {
	y[i][j]=double(rand())/RAND_MAX;
      }
    }
    
    for(int i=0;i<m;i++)
    {
      for(int j=0;j<d;j++)
      {
	R[i][j]=0;
	N[i][j]=0;
	I[i][j]=0;
	S[i][j]=0;
      }
    }
    for(int j=0;j<d;j++) {
      I[m][j]=0;
      int_err[j] =0;
    }
    //////////////////////////////////////////////////
    //               Adapt grid                     //
    //////////////////////////////////////////////////
    for (int i=0;i<n;i++)
    {
      jacobian = 1;

      // Find, for each direction [j], the index of the interval
      // containing the random point y[i][j] and calculates the
      // corresponding x value via the h function
      for(int j=0;j<d;j++)
      { 
	k[j] = int(y[i][j]/delta_y);
	h[j] = h_function(y[i][j],Y[k[j]][j],Y[k[j]+1][j],X[k[j]][j],X[k[j]+1][j]);
	jacobian *= X[k[j]+1][j]-X[k[j]][j];
      }
      // Accumulates the integrand			
      for(int j=0;j<d;j++)
      { 
	R[k[j]][j]+=f(h)*jacobian; 
	N[k[j]][j]+=1;
      }
    }
    
    // Accumulates the integral function I	
    for(int l=0;l<d;l++)
    {
      for(int i=1;i<m+1;i++)
      {
	for(int j=0;j<i;j++)
	{
	  I[i][l]+=R[j][l]/N[j][l];
	}
      }
    }
    // Calculates new grid points
    for (int i=0;i<d;i++)
    {
      // Solving the condition of having constant
      // integrand in each interval
      for(int l=1;l<m+1;l++)
      {
	// For each interval l
	I_L=(double(l)/m)*I[m][i];
	for(int j=0;j<m;j++)
	{
	  // Find the first index j which integral function
	  // bounds the one at interval l
	  if (I[j][i]<=I_L && I_L<=I[j+1][i])
	  {
	    L=j+1; // Set the index of such interval
	    j=m;   // Once found, break the cycle
	  } 
	}
	// New points
	X_new[l][i] = X[L-1][i]+((X[L][i]-X[L-1][i])/(I[L][i]-I[L-1][i]))*(I[m][i]*double(l)/m-I[L-1][i]);
      }
    }
    for(int i=0;i<d;i++)
    {
      for(int l=1;l<m+1;l++)
      {
	X[l][i]=X_new[l][i];
	_grid[l][i]=X_new[l][i];
      }
    }
    //////////////////////////////////////////////////
    //             Calculate Integral               //
    //////////////////////////////////////////////////
    for(int i=0;i<n;i++)
    {
      // Same process as before
      jacobian =1;
      for(int j=0;j<d;j++)
      {
	k[j] = int(y[i][j]/delta_y);
	h[j] = h_function(y[i][j],Y[k[j]][j],Y[k[j]+1][j],X[k[j]][j],X[k[j]+1][j]);
	jacobian *= (X[k[j]+1][j]-X[k[j]][j])/(Y[k[j]+1][j]-Y[k[j]][j]);
      }
      integrand = f(h);

      // Find maximum of the function in the intervals
      for(int j=0;j<d;j++)
      {
	if (integrand > S[k[j]][j])
	{
	  S[k[j]][j] = integrand;
	}
      }
      // Accumulates result
      integrand = integrand*jacobian;
      Int+= (1./n)*integrand;
      IInt += (1./n)*integrand*integrand;
    }
    // Evaluating the error to check loop condition
    for (int s=0;s<d;s++)
    {	
      for (int i=0;i<m;i++)
      {
	for(int j=0;j<i;j++)
	{
	  if(abs(R[i][s]/N[i][s]-R[j][s]/N[j][s]) > int_err[s])
	  {
	    int_err[s] = abs(R[i][s]/N[i][s]-R[j][s]/N[j][s]);
	  }
	}
      }
    }
  }

  _integral = Int;
  _error = sqrt( abs(IInt - Int*Int) / n );
  //////////////////////////////////////////////////
  //                 End While                    //
  //////////////////////////////////////////////////
  return;
}

void MultiIntegral::plot_grid()
{
  ofstream out_file;
  const char* filename = "adaptive-grid.data";
  int sys;
  int N = 100;
  double y;
  out_file.open(filename);

  for(int i=0 ; i<_n_points+1; i++)
  {
    for(int j=0 ; j<N; j++)
    {
      y = (double)j/N;
      out_file
	<<_grid[i][0] <<"\t"
	<< y <<endl;
    }
    out_file <<endl;
  }

  for(int i=0 ; i<_n_points+1; i++)
  {
    for(int j=0 ; j<N; j++)
    {
      y = (double)j/N;
      out_file
	<< y <<"\t"
      	<<_grid[i][1] <<endl;
    }
    out_file <<endl;
  }
  
  out_file.close();
  //  sys = system("less adaptive-grid.data");
  sys = system("gnuplot -p adaptive-grid.gnu");

  return;
}

#endif
